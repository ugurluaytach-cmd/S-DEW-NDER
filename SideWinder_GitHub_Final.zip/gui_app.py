"""
gui_app.py  ─  SideWinder FFB  ·  Modern Desktop UI
====================================================
CustomTkinter ile dark-mode gaming arayüzü.
Mevcut sidewinder_ffb.py mantığını tamamen sarar.

Bağımlılıklar (bir kez kur):
    pip install customtkinter pysdl2 pysdl2-dll pystray Pillow

Çalıştır:
    py -3.12 gui_app.py
"""

from __future__ import annotations

import os, sys, math, time, json, threading, pathlib, logging
from typing import Optional

# ── CustomTkinter ────────────────────────────────────────────────────────────
try:
    import customtkinter as ctk
    CTK_OK = True
except ImportError:
    CTK_OK = False
    print("CustomTkinter yuklu degil!")
    print("Calistir: pip install customtkinter")
    sys.exit(1)

from PIL import Image, ImageDraw

# ── Gamepad emülatörü (ViGEmBus gerektirir) ──────────────────────────────────
try:
    import vgamepad as vg
    VGAMEPAD_OK = True
except ImportError:
    VGAMEPAD_OK = False
try:
    import pystray
    TRAY_OK = True
except ImportError:
    TRAY_OK = False

# ── Mevcut FFB motoru ve telemetri sistemi ────────────────────────────────────
# sidewinder_ffb.py ile aynı klasörde olduğu varsayılır
sys.path.insert(0, str(pathlib.Path(__file__).parent))
try:
    from sidewinder_ffb import (
        Motor, Alici, Ayar, kontrol,
        Kare, Zemin, APPDIR, LOGDOS, AYARDOS,
        AD as FFB_AD, SURUM as FFB_SURUM,
        _SDL2, _TRAY
    )
    FFB_OK = True
except ImportError as e:
    FFB_OK = False
    print(f"sidewinder_ffb.py yuklenemedi: {e}")
    print("gui_app.py ile ayni klasorde olmali!")

# ── Sabitler ──────────────────────────────────────────────────────────────────
APP_ADI    = "SideWinder FFB"
SURUM      = "4.0"
PROJE      = pathlib.Path(__file__).parent.resolve()
IKON_DOS   = PROJE / "icon.ico"
LOG        = logging.getLogger("gui")

# ── Renk paleti ───────────────────────────────────────────────────────────────
class Renk:
    BG          = "#0f1117"      # Ana arka plan
    BG2         = "#161b27"      # Panel
    BG3         = "#1e2535"      # Kart
    ACCENT      = "#3b82f6"      # Mavi vurgu
    ACCENT2     = "#6366f1"      # İndigo
    YESIL       = "#22c55e"
    SARI        = "#f59e0b"
    KIRMIZI     = "#ef4444"
    TURUNCU     = "#f97316"
    METIN       = "#e2e8f0"
    METIN_YSL   = "#94a3b8"
    CERCEVE     = "#2d3748"

# ════════════════════════════════════════════════════════════════════════════
# Özel widget'lar
# ════════════════════════════════════════════════════════════════════════════

class StatusBadge(ctk.CTkFrame):
    """Yeşil/Sarı/Kırmızı durum rozeti."""
    def __init__(self, master, metin="Bekleniyor", **kw):
        super().__init__(master, fg_color=Renk.BG3,
                         corner_radius=20, **kw)
        self._dot = ctk.CTkLabel(self, text="●", width=16,
                                  font=ctk.CTkFont(size=12))
        self._dot.pack(side="left", padx=(10,2), pady=6)
        self._lbl = ctk.CTkLabel(self, text=metin, width=160,
                                  font=ctk.CTkFont(size=11, weight="bold"),
                                  anchor="w")
        self._lbl.pack(side="left", padx=(2,12), pady=6)

    def guncelle(self, metin:str, renk:str):
        self._dot.configure(text_color=renk)
        self._lbl.configure(text=metin, text_color=renk)


class GKuvvetBar(ctk.CTkFrame):
    """Yanal G-kuvveti görsel göstergesi (canvas-tabanlı)."""
    def __init__(self, master, **kw):
        super().__init__(master, fg_color=Renk.BG3,
                         corner_radius=10, **kw)
        import tkinter as tk
        self._cv = tk.Canvas(self, height=32, bg=Renk.BG3,
                              bd=0, highlightthickness=0)
        self._cv.pack(fill="x", padx=8, pady=8)
        self._g_max = 3.0

    def ciz(self, g:float, g_max:float=3.0):
        self._g_max = g_max
        cv = self._cv
        cv.delete("all")
        w = cv.winfo_width() or 400
        h = 32
        cx = w // 2

        # Arka plan çizgisi
        cv.create_line(0, h//2, w, h//2, fill=Renk.CERCEVE, width=1)
        cv.create_line(cx, 4, cx, h-4, fill=Renk.METIN_YSL, width=1)

        # G-bar
        norm = max(-1.0, min(1.0, g / max(g_max, 0.1)))
        bar  = int(abs(norm) * (w//2 - 12))
        if bar > 0:
            renk = Renk.KIRMIZI if abs(g) > g_max * 0.8 else \
                   Renk.SARI    if abs(g) > g_max * 0.5 else \
                   (Renk.YESIL if g >= 0 else Renk.ACCENT)
            if g >= 0:
                cv.create_rectangle(cx, 10, cx+bar, h-10,
                                     fill=renk, outline="")
            else:
                cv.create_rectangle(cx-bar, 10, cx, h-10,
                                     fill=renk, outline="")

        cv.create_text(cx, h//2, text=f"Yanal G:  {g:+.3f} G",
                       fill=Renk.METIN,
                       font=("Consolas", 9, "bold"))


class KartCerceve(ctk.CTkFrame):
    """Başlıklı kart bileşeni."""
    def __init__(self, master, baslik:str, ikon:str="", **kw):
        super().__init__(master, fg_color=Renk.BG2,
                         corner_radius=12,
                         border_width=1,
                         border_color=Renk.CERCEVE, **kw)
        baslik_f = ctk.CTkFrame(self, fg_color=Renk.BG3,
                                 corner_radius=0, height=36)
        baslik_f.pack(fill="x", padx=0, pady=0)
        baslik_f.pack_propagate(False)

        ctk.CTkLabel(baslik_f,
                     text=f"  {ikon}  {baslik}" if ikon else f"  {baslik}",
                     font=ctk.CTkFont(size=11, weight="bold"),
                     text_color=Renk.ACCENT,
                     anchor="w").pack(side="left", fill="y", padx=4)

        self.ic = ctk.CTkFrame(self, fg_color="transparent")
        self.ic.pack(fill="both", expand=True, padx=12, pady=10)


class FFBSlider(ctk.CTkFrame):
    """Etiket + kaydırıcı + değer göstergesi."""
    def __init__(self, master, etiket:str, min_v:float, max_v:float,
                 baslangic:float, format_str:str="{:.0%}",
                 renk:str=Renk.ACCENT, degisti_cb=None, **kw):
        super().__init__(master, fg_color="transparent", **kw)
        self._fmt = format_str
        self._cb  = degisti_cb

        ust = ctk.CTkFrame(self, fg_color="transparent")
        ust.pack(fill="x")

        ctk.CTkLabel(ust, text=etiket,
                     font=ctk.CTkFont(size=10),
                     text_color=Renk.METIN_YSL,
                     anchor="w").pack(side="left")

        self._val_lbl = ctk.CTkLabel(ust, text=format_str.format(baslangic),
                                      font=ctk.CTkFont("Consolas", 10, "bold"),
                                      text_color=renk, width=60, anchor="e")
        self._val_lbl.pack(side="right")

        self._var = ctk.DoubleVar(value=baslangic)
        self._sl  = ctk.CTkSlider(self, from_=min_v, to=max_v,
                                   variable=self._var,
                                   progress_color=renk,
                                   button_color=renk,
                                   button_hover_color="#ffffff",
                                   command=self._degisti)
        self._sl.pack(fill="x", pady=(4,0))

    def _degisti(self, v):
        self._val_lbl.configure(text=self._fmt.format(float(v)))
        if self._cb:
            self._cb(float(v))

    @property
    def deger(self) -> float:
        return self._var.get()

    def ayarla(self, v:float):
        self._var.set(v)
        self._val_lbl.configure(text=self._fmt.format(v))


# ════════════════════════════════════════════════════════════════════════════
# Ana uygulama penceresi
# ════════════════════════════════════════════════════════════════════════════

class SideWinderApp(ctk.CTk):
    """
    Tüm UI'ı barındıran ana pencere.
    FFB mantığı, Motor ve Alici nesneleri burada yaşar.
    """

    def __init__(self):
        super().__init__()

        # ── Pencere temel ayarları ────────────────────────────────────────────
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.title(f"{APP_ADI}  ─  v{SURUM}")
        self.geometry("820x700")
        self.minsize(740, 600)
        self.configure(fg_color=Renk.BG)

        # İkon
        if IKON_DOS.exists():
            try: self.iconbitmap(str(IKON_DOS))
            except Exception: pass

        # Kapatınca tray'e gizle
        self.protocol("WM_DELETE_WINDOW", self._gizle)

        # ── FFB motoru ve telemetri ───────────────────────────────────────────
        if FFB_OK:
            self._ayar  = Ayar.yukle()
            self._motor  = Motor()
            self._alici  = Alici(port=self._ayar.udp_port)
        else:
            self._ayar   = None
            self._motor  = None
            self._alici  = None

        self._cal        = False
        self._dur_ctrl   = threading.Event()
        self._ctrl_ip:   Optional[threading.Thread] = None
        self._tray_ikon  = None

        # ── Joystick ham durum (polling thread → UI thread) ───────────────────
        # Lock altında paylaşılan tek tuple — atomic swap ile race yok
        self._js_lock   = threading.Lock()
        self._js_state  = {"btns": {}, "axes": {}, "hats": []}
        self._js_poll_stop = threading.Event()
        self._js_poll_ip:  Optional[threading.Thread] = None
        # Önceki frame'deki buton durumu (edge detection için)
        self._js_prev_btns: dict[int, bool] = {}

        # ── Gamepad emülatör durumu ────────────────────────────────────────────
        self._emul_aktif   = False
        self._emul_gamepad = None          # vg.VX360Gamepad instance
        self._emul_stop    = threading.Event()
        self._emul_ip:     Optional[threading.Thread] = None
        # Emülatör parametreleri (UI slider'lardan okunur)
        self._emul_deadzone  = 0.05
        self._emul_sens_steer = 1.0
        self._emul_sens_ped   = 1.0
        self._emul_invert_steer = False

        # Kalibrasyon: merkez offset ve limit değerleri
        # Bunlar poll thread tarafından ölçülen ham axis verilerine uygulanır
        self._calib_center: float = 0.0      # merkez offset (sıfırlama noktası)
        self._calib_min:    float = -1.0     # tam sol sınır
        self._calib_max:    float =  1.0     # tam sağ sınır
        self._calib_kayitli = False          # öğretme tamamlandı mı

        # Sanal gamepad'e son gönderilen değerler — UI monitor için
        self._vgp_snapshot_lock = threading.Lock()
        self._vgp_snapshot: dict = {
            "lx": 0, "ly": 0, "rx": 0, "ry": 0,
            "lt": 0, "rt": 0,
            "steer_norm": 0.0, "gas_pct": 0.0, "brk_pct": 0.0,
        }

        # ── UI inşa ───────────────────────────────────────────────────────────
        self._ui_olustur()

        # ── SDL2 joystick polling başlat (FFB motorundan bağımsız) ───────────
        self._js_poll_baslat()

        # ── Canlı güncelleme döngüsü ──────────────────────────────────────────
        self._guncelle_dongusu()

    # ═══════════════════════════════════════════════════════════════════════
    # UI İnşası
    # ═══════════════════════════════════════════════════════════════════════

    def _ui_olustur(self):

        # ── Üst başlık çubuğu ─────────────────────────────────────────────────
        baslik_f = ctk.CTkFrame(self, fg_color=Renk.BG3, height=60,
                                 corner_radius=0)
        baslik_f.pack(fill="x", side="top")
        baslik_f.pack_propagate(False)

        ctk.CTkLabel(baslik_f,
                     text=f"  🎮  {APP_ADI}",
                     font=ctk.CTkFont("Segoe UI", 18, "bold"),
                     text_color=Renk.ACCENT).pack(side="left", padx=16)

        ctk.CTkLabel(baslik_f,
                     text=f"v{SURUM}  ·  Python {sys.version.split()[0]}",
                     font=ctk.CTkFont("Segoe UI", 9),
                     text_color=Renk.METIN_YSL).pack(side="left")

        # Sağ: Durum rozeti
        self._badge = StatusBadge(baslik_f, "Bağlantı Yok")
        self._badge.pack(side="right", padx=16, pady=10)

        # ── Sol panel + Sağ panel ─────────────────────────────────────────────
        govde = ctk.CTkFrame(self, fg_color="transparent")
        govde.pack(fill="both", expand=True, padx=12, pady=8)

        sol = ctk.CTkFrame(govde, fg_color="transparent", width=300)
        sol.pack(side="left", fill="y", padx=(0,6))
        sol.pack_propagate(False)

        sag = ctk.CTkFrame(govde, fg_color="transparent")
        sag.pack(side="left", fill="both", expand=True)

        # ── Sol panel içeriği ─────────────────────────────────────────────────
        self._baglanti_karti(sol)
        self._ffb_slider_karti(sol)
        self._zemin_karti(sol)

        # ── Sağ panel: sekmeli görünüm ────────────────────────────────────────
        self._tabs = ctk.CTkTabview(
            sag,
            fg_color=Renk.BG2,
            segmented_button_fg_color=Renk.BG3,
            segmented_button_selected_color=Renk.ACCENT,
            segmented_button_selected_hover_color="#2563eb",
            segmented_button_unselected_color=Renk.BG3,
            segmented_button_unselected_hover_color=Renk.CERCEVE,
            text_color=Renk.METIN,
            text_color_disabled=Renk.METIN_YSL,
        )
        self._tabs.pack(fill="both", expand=True)

        self._tabs.add("📡  Gösterge")
        self._tabs.add("🎮  Buton Haritası")
        self._tabs.add("🔧  Direksiyon Ayarı")
        self._tabs.add("🕹️  Kalibrasyon")
        self._tabs.add("🖱️  Emülasyon")

        self._telemetri_karti(self._tabs.tab("📡  Gösterge"))
        self._log_karti(self._tabs.tab("📡  Gösterge"))
        self._btn_mapping_sekmesi(self._tabs.tab("🎮  Buton Haritası"))
        self._steering_sekmesi(self._tabs.tab("🔧  Direksiyon Ayarı"))
        self._kalibrasyon_sekmesi(self._tabs.tab("🕹️  Kalibrasyon"))
        self._emulasyon_sekmesi(self._tabs.tab("🖱️  Emülasyon"))

        # ── Alt durum çubuğu ──────────────────────────────────────────────────
        self._alt_cubuk()

    # ── Bağlantı kartı ────────────────────────────────────────────────────────
    def _baglanti_karti(self, parent):
        k = KartCerceve(parent, "Bağlantı ve Kontrol", "🔌")
        k.pack(fill="x", pady=(0,8))

        # Büyük Connect butonu
        self._btn_connect = ctk.CTkButton(
            k.ic,
            text="▶  Başlat / Bağlan",
            height=46,
            font=ctk.CTkFont("Segoe UI", 13, "bold"),
            fg_color=Renk.YESIL,
            hover_color="#16a34a",
            corner_radius=10,
            command=self._togel
        )
        self._btn_connect.pack(fill="x", pady=(0,8))

        # Cihaz bilgisi
        self._cihaz_lbl = ctk.CTkLabel(
            k.ic, text="Cihaz: Aranıyor...",
            font=ctk.CTkFont("Segoe UI", 10),
            text_color=Renk.METIN_YSL, anchor="w"
        )
        self._cihaz_lbl.pack(fill="x")

        # UDP port
        port_f = ctk.CTkFrame(k.ic, fg_color="transparent")
        port_f.pack(fill="x", pady=(6,0))

        ctk.CTkLabel(port_f, text="UDP Port:",
                     font=ctk.CTkFont(size=10),
                     text_color=Renk.METIN_YSL,
                     width=80, anchor="w").pack(side="left")

        self._port_var = ctk.StringVar(
            value=str(self._ayar.udp_port if self._ayar else 20777))
        self._port_entry = ctk.CTkEntry(
            port_f, textvariable=self._port_var,
            width=80, height=28,
            font=ctk.CTkFont("Consolas", 10),
            fg_color=Renk.BG3
        )
        self._port_entry.pack(side="left", padx=(4,0))

        ctk.CTkLabel(port_f, text="(Forza/F1: 20777)",
                     font=ctk.CTkFont(size=9),
                     text_color=Renk.METIN_YSL).pack(side="left", padx=6)

    # ── FFB Slider kartı ──────────────────────────────────────────────────────
    def _ffb_slider_karti(self, parent):
        k = KartCerceve(parent, "Force Feedback Parametreleri", "🎛")
        k.pack(fill="x", pady=(0,8))

        a = self._ayar

        self._sl_yay_max = FFBSlider(
            k.ic, "Yay (Centering Spring) Gücü",
            0.0, 1.0, a.yay_max if a else 0.88,
            "{:.0%}", Renk.ACCENT,
            degisti_cb=lambda v: setattr(a,"yay_max",v) if a else None
        )
        self._sl_yay_max.pack(fill="x", pady=4)

        self._sl_son = FFBSlider(
            k.ic, "Damper (Sönümleme) Gücü",
            0.0, 1.0, a.son_taban if a else 0.20,
            "{:.0%}", Renk.ACCENT2,
            degisti_cb=lambda v: setattr(a,"son_taban",v) if a else None
        )
        self._sl_son.pack(fill="x", pady=4)

        self._sl_g = FFBSlider(
            k.ic, "Max G-Kuvveti Eşiği",
            0.5, 6.0, a.g_max if a else 3.0,
            "{:.1f} G", Renk.SARI,
            degisti_cb=lambda v: setattr(a,"g_max",v) if a else None
        )
        self._sl_g.pack(fill="x", pady=4)

        self._sl_son_g = FFBSlider(
            k.ic, "G-Bazlı Ek Sönümleme",
            0.0, 1.0, a.son_g if a else 0.38,
            "{:.0%}", Renk.TURUNCU,
            degisti_cb=lambda v: setattr(a,"son_g",v) if a else None
        )
        self._sl_son_g.pack(fill="x", pady=4)

        # Kaydet butonu
        kaydet_f = ctk.CTkFrame(k.ic, fg_color="transparent")
        kaydet_f.pack(fill="x", pady=(8,0))

        self._kaydet_lbl = ctk.CTkLabel(
            kaydet_f, text="",
            font=ctk.CTkFont(size=9),
            text_color=Renk.YESIL
        )
        self._kaydet_lbl.pack(side="right", padx=4)

        ctk.CTkButton(
            kaydet_f, text="Ayarları Kaydet",
            height=30, width=130,
            font=ctk.CTkFont(size=10, weight="bold"),
            fg_color=Renk.BG3,
            hover_color=Renk.ACCENT,
            command=self._ayarlari_kaydet
        ).pack(side="right")

        ctk.CTkButton(
            kaydet_f, text="Sıfırla",
            height=30, width=70,
            font=ctk.CTkFont(size=10),
            fg_color=Renk.BG3,
            hover_color=Renk.CERCEVE,
            command=self._ayarlari_sifirla
        ).pack(side="right", padx=(0,6))

    # ── Zemin efektleri kartı ─────────────────────────────────────────────────
    def _zemin_karti(self, parent):
        k = KartCerceve(parent, "Zemin Titreşim Efektleri", "🏁")
        k.pack(fill="x", pady=(0,8))

        self._sin_sw = ctk.CTkSwitch(
            k.ic, text="Zemin Titreşimi (Sinüs)",
            font=ctk.CTkFont(size=10),
            progress_color=Renk.ACCENT
        )
        self._sin_sw.select()
        self._sin_sw.pack(anchor="w", pady=2)

        efektler = [
            ("Çim",    "●  CIM",    Renk.YESIL),
            ("Toprak", "●  TOPRAK", Renk.TURUNCU),
            ("Çakıl",  "●  CAKIL",  Renk.SARI),
            ("Buz",    "●  BUZ",    Renk.ACCENT),
        ]
        for _, metin, renk in efektler:
            ctk.CTkLabel(k.ic, text=metin,
                         font=ctk.CTkFont("Consolas", 9),
                         text_color=renk, anchor="w").pack(
                fill="x", padx=4, pady=1)

    # ── Telemetri kartı ───────────────────────────────────────────────────────
    def _telemetri_karti(self, parent):
        k = KartCerceve(parent, "Canlı Telemetri", "📡")
        k.pack(fill="x", pady=(0,8))

        # G-bar
        self._g_bar = GKuvvetBar(k.ic)
        self._g_bar.pack(fill="x", pady=(0,8))

        # Metrik grid
        self._metrik_frame = ctk.CTkFrame(k.ic, fg_color="transparent")
        self._metrik_frame.pack(fill="x")

        metriks = [
            ("Yanal G",    "m_yanal",    "---"),
            ("Boysal G",   "m_boysal",   "---"),
            ("Hız",        "m_hiz",      "---"),
            ("Zemin",      "m_zemin",    "---"),
            ("Yaw Hızı",   "m_yaw",      "---"),
            ("Kaynak",     "m_kaynak",   "---"),
        ]

        self._metrik_lbls: dict[str, ctk.CTkLabel] = {}
        for i, (etiket, key, varsayilan) in enumerate(metriks):
            row, col = divmod(i, 2)
            hucre = ctk.CTkFrame(self._metrik_frame, fg_color=Renk.BG3,
                                  corner_radius=8)
            hucre.grid(row=row, column=col, padx=4, pady=3,
                       sticky="ew")
            self._metrik_frame.grid_columnconfigure(col, weight=1)

            ctk.CTkLabel(hucre, text=etiket,
                         font=ctk.CTkFont(size=9),
                         text_color=Renk.METIN_YSL,
                         anchor="w").pack(anchor="w", padx=8, pady=(6,0))

            val = ctk.CTkLabel(hucre, text=varsayilan,
                                font=ctk.CTkFont("Consolas", 11, "bold"),
                                text_color=Renk.METIN, anchor="w")
            val.pack(anchor="w", padx=8, pady=(0,6))
            self._metrik_lbls[key] = val

        # FFB güç göstergeleri
        guc_f = ctk.CTkFrame(k.ic, fg_color="transparent")
        guc_f.pack(fill="x", pady=(10,0))

        self._ffb_bars: dict[str, ctk.CTkProgressBar] = {}
        for ad, key, renk in [
            ("Yay", "yay", Renk.ACCENT),
            ("Sön", "son", Renk.ACCENT2),
            ("Sin", "sin", Renk.YESIL),
        ]:
            col_f = ctk.CTkFrame(guc_f, fg_color="transparent")
            col_f.pack(side="left", fill="x", expand=True, padx=4)

            ctk.CTkLabel(col_f, text=ad,
                         font=ctk.CTkFont(size=9),
                         text_color=Renk.METIN_YSL).pack()

            pb = ctk.CTkProgressBar(col_f, height=8,
                                     progress_color=renk,
                                     fg_color=Renk.BG3)
            pb.set(0)
            pb.pack(fill="x")
            self._ffb_bars[key] = pb

    # ── Log kartı ─────────────────────────────────────────────────────────────
    def _log_karti(self, parent):
        k = KartCerceve(parent, "Uygulama Logu", "📋")
        k.pack(fill="both", expand=True)

        self._log_box = ctk.CTkTextbox(
            k.ic,
            font=ctk.CTkFont("Consolas", 9),
            fg_color=Renk.BG,
            text_color=Renk.METIN_YSL,
            wrap="none",
            state="disabled"
        )
        self._log_box.pack(fill="both", expand=True)

    # ── Alt çubuk ─────────────────────────────────────────────────────────────
    def _alt_cubuk(self):
        alt = ctk.CTkFrame(self, fg_color=Renk.BG3, height=36,
                            corner_radius=0)
        alt.pack(fill="x", side="bottom")
        alt.pack_propagate(False)

        ctk.CTkLabel(alt,
                     text=f"  Log: {LOGDOS}",
                     font=ctk.CTkFont(size=8),
                     text_color=Renk.METIN_YSL,
                     anchor="w").pack(side="left", padx=4)

        ctk.CTkButton(alt, text="Tray'e Gizle",
                       height=26, width=110,
                       font=ctk.CTkFont(size=9),
                       fg_color=Renk.BG,
                       hover_color=Renk.CERCEVE,
                       command=self._gizle).pack(side="right", padx=4, pady=4)

        ctk.CTkButton(alt, text="Log Klasörü",
                       height=26, width=100,
                       font=ctk.CTkFont(size=9),
                       fg_color=Renk.BG,
                       hover_color=Renk.CERCEVE,
                       command=lambda: os.startfile(str(APPDIR))).pack(
            side="right", padx=2, pady=4)

    # ═══════════════════════════════════════════════════════════════════════
    # FFB Kontrol
    # ═══════════════════════════════════════════════════════════════════════

    def _togel(self):
        if self._cal:
            self._durdur()
        else:
            self._baslat()

    def _baslat(self):
        if self._cal or not FFB_OK:
            return
        try:
            self._ayar.udp_port = int(self._port_var.get())
        except ValueError:
            pass

        self._btn_connect.configure(
            text="⏸  Durduruluyor...",
            fg_color=Renk.SARI, hover_color="#d97706"
        )
        self._badge.guncelle("Bağlanıyor...", Renk.SARI)
        LOG.info("FFB başlatılıyor...")

        threading.Thread(target=self._ffb_baslat_thread,
                         daemon=True, name="FFBInit").start()

    def _ffb_baslat_thread(self):
        ok = self._motor.baslat()
        self._alici.baslat()

        self._dur_ctrl.clear()
        self._ctrl_ip = threading.Thread(
            target=kontrol,
            args=(self._motor, self._alici, self._dur_ctrl, self._ayar),
            daemon=True, name="Kontrol"
        )
        self._ctrl_ip.start()
        self._cal = True

        cihaz = "SideWinder FF2" if self._motor._haz else "Simülasyon"
        self.after(0, lambda: self._btn_connect.configure(
            text="■  Durdur",
            fg_color=Renk.KIRMIZI,
            hover_color="#b91c1c"
        ))
        self.after(0, lambda: self._badge.guncelle(
            f"● Aktif  [{cihaz}]",
            Renk.YESIL if self._motor._haz else Renk.SARI
        ))
        self.after(0, lambda: self._cihaz_lbl.configure(
            text=f"Cihaz: {cihaz}"
        ))
        LOG.info("FFB hazır. UDP %d", self._ayar.udp_port)

    def _durdur(self):
        if not self._cal:
            return
        self._dur_ctrl.set()
        if self._ctrl_ip:
            self._ctrl_ip.join(timeout=2)
        try:
            self._alici.durdur()
            self._motor.dur()
            self._motor.kapat()
        except Exception as e:
            LOG.warning("Durdurma: %s", e)

        # Nesneleri sıfırla
        if FFB_OK:
            self._motor = Motor()
            self._alici = Alici(port=self._ayar.udp_port)

        self._cal = False
        self._btn_connect.configure(
            text="▶  Başlat / Bağlan",
            fg_color=Renk.YESIL, hover_color="#16a34a"
        )
        self._badge.guncelle("Durduruldu", Renk.KIRMIZI)
        self._cihaz_lbl.configure(text="Cihaz: Bağlı Değil")
        LOG.info("FFB durduruldu.")

    # ═══════════════════════════════════════════════════════════════════════
    # Ayarlar
    # ═══════════════════════════════════════════════════════════════════════

    def _ayarlari_kaydet(self):
        if self._ayar:
            try:
                self._ayar.udp_port = int(self._port_var.get())
            except ValueError:
                pass
            self._ayar.kaydet()
            self._kaydet_lbl.configure(text="✓ Kaydedildi!")
            self.after(2500, lambda: self._kaydet_lbl.configure(text=""))

    def _ayarlari_sifirla(self):
        if not FFB_OK:
            return
        yeni = Ayar()
        self._sl_yay_max.ayarla(yeni.yay_max)
        self._sl_son.ayarla(yeni.son_taban)
        self._sl_g.ayarla(yeni.g_max)
        self._sl_son_g.ayarla(yeni.son_g)
        if self._ayar:
            for k, v in yeni.__dict__.items():
                setattr(self._ayar, k, v)

    # ═══════════════════════════════════════════════════════════════════════
    # Sekme: Buton Haritası
    # ═══════════════════════════════════════════════════════════════════════

    def _btn_mapping_sekmesi(self, parent):
        """
        SideWinder FF2'nin 8 butonu + 2 paddle için atama arayüzü.
        Her satır:  [Buton adı + simgesi]  [Mevcut atama]  [Değiştir butonu]
        Üstte wheel canvas görseli.
        """
        # Desteklenen fonksiyon listesi
        self._btn_fonksiyonlar = [
            "-- Atanmamış --",
            "Shift Up",
            "Shift Down",
            "Handbrake",
            "Horn / Klakson",
            "Boost / NOS",
            "Look Back",
            "Pit Limiter",
            "TC Artır",
            "TC Azalt",
            "ABS Artır",
            "ABS Azalt",
            "Fren Dengesi +",
            "Fren Dengesi -",
            "MFD İleri",
            "MFD Geri",
            "Ekran Görüntüsü",
        ]

        # Varsayılan atamalar (ayar dosyasından yüklenir)
        default_map = {
            "Btn 1 (A)":          "Shift Up",
            "Btn 2 (B)":          "Shift Down",
            "Btn 3 (X)":          "Handbrake",
            "Btn 4 (Y)":          "Horn / Klakson",
            "Btn 5 (LB)":         "TC Azalt",
            "Btn 6 (RB)":         "TC Artır",
            "Btn 7 (Start)":      "Pit Limiter",
            "Btn 8 (Select)":     "Look Back",
            "Sol Paddle (L2)":    "Shift Down",
            "Sağ Paddle (R2)":    "Shift Up",
            "D-Pad ↑":            "MFD İleri",
            "D-Pad ↓":            "MFD Geri",
        }

        # Ayar dosyasından yükle
        saved = {}
        try:
            if AYARDOS.exists():
                saved = json.loads(AYARDOS.read_text("utf-8")).get("btn_map", {})
        except Exception:
            pass
        atamalar = {k: saved.get(k, v) for k, v in default_map.items()}

        self._btn_atamalar: dict[str, ctk.StringVar] = {}

        # Üst: Direksiyon görseli (canvas)
        canvas_f = ctk.CTkFrame(parent, fg_color=Renk.BG2, corner_radius=12)
        canvas_f.pack(fill="x", padx=8, pady=(8,4))

        import tkinter as tk
        self._wheel_cv = tk.Canvas(canvas_f, height=120, bg=Renk.BG2,
                                    bd=0, highlightthickness=0)
        self._wheel_cv.pack(fill="x", padx=8, pady=8)
        self._wheel_cv.bind("<Configure>", lambda e: self._wheel_ciz())
        self.after(100, self._wheel_ciz)

        # Alt: Tablo
        tablo_f = ctk.CTkScrollableFrame(parent, fg_color=Renk.BG,
                                          corner_radius=0)
        tablo_f.pack(fill="both", expand=True, padx=8, pady=(0,8))

        # Başlık satırı
        baslik_satir = ctk.CTkFrame(tablo_f, fg_color=Renk.BG3,
                                     corner_radius=6)
        baslik_satir.pack(fill="x", pady=(0,4))
        baslik_satir.grid_columnconfigure(0, weight=2)
        baslik_satir.grid_columnconfigure(1, weight=3)
        baslik_satir.grid_columnconfigure(2, weight=1)

        for col, txt in enumerate(["Buton / Kontrol", "Atanan Fonksiyon", ""]):
            ctk.CTkLabel(baslik_satir, text=txt,
                         font=ctk.CTkFont(size=10, weight="bold"),
                         text_color=Renk.ACCENT,
                         anchor="w").grid(row=0, column=col, padx=8, pady=6,
                                          sticky="ew")

        # İkonlar
        ikon_map = {
            "Btn 1 (A)": "🔴", "Btn 2 (B)": "🔵",
            "Btn 3 (X)": "🟡", "Btn 4 (Y)": "🟢",
            "Btn 5 (LB)": "◀",  "Btn 6 (RB)": "▶",
            "Btn 7 (Start)": "▶️", "Btn 8 (Select)": "⬛",
            "Sol Paddle (L2)": "⬅", "Sağ Paddle (R2)": "➡",
            "D-Pad ↑": "⬆", "D-Pad ↓": "⬇",
        }

        for btn_adi, varsayilan in atamalar.items():
            satir = ctk.CTkFrame(tablo_f, fg_color=Renk.BG2,
                                  corner_radius=6)
            satir.pack(fill="x", pady=2)
            satir.grid_columnconfigure(0, weight=2)
            satir.grid_columnconfigure(1, weight=3)
            satir.grid_columnconfigure(2, weight=1)

            ikon = ikon_map.get(btn_adi, "●")
            ctk.CTkLabel(satir,
                         text=f"  {ikon}  {btn_adi}",
                         font=ctk.CTkFont(size=10),
                         text_color=Renk.METIN,
                         anchor="w").grid(row=0, column=0, padx=8, pady=6,
                                          sticky="ew")

            var = ctk.StringVar(value=varsayilan)
            self._btn_atamalar[btn_adi] = var

            combo = ctk.CTkOptionMenu(
                satir,
                variable=var,
                values=self._btn_fonksiyonlar,
                font=ctk.CTkFont(size=10),
                fg_color=Renk.BG3,
                button_color=Renk.ACCENT,
                button_hover_color="#2563eb",
                dropdown_fg_color=Renk.BG3,
                dropdown_text_color=Renk.METIN,
                height=30,
                dynamic_resizing=False,
                command=lambda v, a=btn_adi: self._btn_atama_degisti(a, v)
            )
            combo.grid(row=0, column=1, padx=8, pady=4, sticky="ew")

            ctk.CTkButton(
                satir, text="Sıfırla", width=60, height=26,
                font=ctk.CTkFont(size=9),
                fg_color=Renk.BG,
                hover_color=Renk.CERCEVE,
                command=lambda a=btn_adi, d=varsayilan, v=var: (
                    v.set(d), self._btn_atama_degisti(a, d))
            ).grid(row=0, column=2, padx=4, pady=4)

        # Kaydet butonu
        alt_f = ctk.CTkFrame(parent, fg_color="transparent")
        alt_f.pack(fill="x", padx=8, pady=(0,6))

        self._btn_kaydet_lbl = ctk.CTkLabel(
            alt_f, text="", font=ctk.CTkFont(size=9),
            text_color=Renk.YESIL)
        self._btn_kaydet_lbl.pack(side="right", padx=6)

        ctk.CTkButton(
            alt_f, text="Tüm Atamaları Kaydet",
            height=32, width=180,
            font=ctk.CTkFont(size=10, weight="bold"),
            fg_color=Renk.ACCENT,
            hover_color="#2563eb",
            command=self._btn_haritalari_kaydet
        ).pack(side="right")

    def _wheel_ciz(self):
        """Canvas üzerine SideWinder FF2 direksiyon simgesi çiz."""
        cv = self._wheel_cv
        cv.delete("all")
        w = cv.winfo_width() or 500
        h = 120
        cx, cy = w // 2, h // 2
        R  = min(cx - 20, 48)

        # Dış halka
        cv.create_oval(cx-R, cy-R, cx+R, cy+R,
                       outline=Renk.ACCENT, width=5)
        # İç daire (göbek)
        r2 = int(R * 0.28)
        cv.create_oval(cx-r2, cy-r2, cx+r2, cy+r2,
                       fill=Renk.ACCENT, outline="")

        # 3 ışın
        import math as _m
        for ag in [90, 210, 330]:
            rad = _m.radians(ag)
            x1  = cx + int(r2 * _m.cos(rad))
            y1  = cy - int(r2 * _m.sin(rad))
            x2  = cx + int((R-4) * _m.cos(rad))
            y2  = cy - int((R-4) * _m.sin(rad))
            cv.create_line(x1, y1, x2, y2, fill=Renk.ACCENT, width=4)

        # Paddle göstergeleri
        pr = R + 14
        for side, ag, lbl in [(-1, 150, "L2"), (1, 30, "R2")]:
            rad = _m.radians(ag)
            px  = cx + int(pr * _m.cos(rad))
            py  = cy - int(pr * _m.sin(rad))
            cv.create_rectangle(px-12, py-7, px+12, py+7,
                                  fill=Renk.BG3, outline=Renk.ACCENT2, width=2)
            cv.create_text(px, py, text=lbl, fill=Renk.METIN,
                           font=("Consolas", 8, "bold"))

        # Buton noktaları (A B X Y)
        btn_pos = [
            (cx + R + 22, cy - 14, "A", Renk.KIRMIZI),
            (cx + R + 36, cy,       "B", Renk.ACCENT),
            (cx + R + 22, cy + 14,  "X", Renk.SARI),
            (cx + R + 8,  cy,       "Y", Renk.YESIL),
        ]
        for bx, by, bl, bc in btn_pos:
            cv.create_oval(bx-8, by-8, bx+8, by+8, fill=bc, outline="")
            cv.create_text(bx, by, text=bl, fill="black",
                           font=("Consolas", 7, "bold"))

        # LB RB
        for bx, by, bl in [
            (cx - R - 22, cy - 22, "LB"),
            (cx + R + 22, cy - 22, "RB"),
        ]:
            cv.create_rectangle(bx-14, by-8, bx+14, by+8,
                                  fill=Renk.BG3, outline=Renk.METIN_YSL, width=1)
            cv.create_text(bx, by, text=bl, fill=Renk.METIN,
                           font=("Consolas", 8))

        # Etiket
        cv.create_text(cx, h - 10,
                       text="SideWinder Force Feedback 2",
                       fill=Renk.METIN_YSL,
                       font=("Segoe UI", 8))

    def _btn_atama_degisti(self, btn_adi: str, yeni_fonk: str):
        LOG.debug("Buton atama: %s → %s", btn_adi, yeni_fonk)

    def _btn_haritalari_kaydet(self):
        if not FFB_OK or not self._ayar:
            return
        # btn_map'i ayar nesnesine ekle (Ayar dataclass'ının dışında JSON'a gömülür)
        harita = {k: v.get() for k, v in self._btn_atamalar.items()}
        try:
            mevcut = {}
            if AYARDOS.exists():
                mevcut = json.loads(AYARDOS.read_text("utf-8"))
            mevcut["btn_map"] = harita
            AYARDOS.write_text(json.dumps(mevcut, indent=2, ensure_ascii=False),
                                "utf-8")
            self._btn_kaydet_lbl.configure(text="✓ Kaydedildi!")
            self.after(2500, lambda: self._btn_kaydet_lbl.configure(text=""))
            LOG.info("Buton haritası kaydedildi.")
        except Exception as e:
            LOG.error("Buton haritası kayıt hatası: %s", e)

    # ═══════════════════════════════════════════════════════════════════════
    # Sekme: Direksiyon Ayarları
    # ═══════════════════════════════════════════════════════════════════════

    def _steering_sekmesi(self, parent):
        """Dönüş açısı, deadzone, lineerlik, FFB filtresi ayarları."""

        sc = ctk.CTkScrollableFrame(parent, fg_color="transparent")
        sc.pack(fill="both", expand=True, padx=8, pady=8)

        def bolum(baslik, ikon=""):
            k = KartCerceve(sc, baslik, ikon)
            k.pack(fill="x", pady=(0,10))
            return k.ic

        # ── Dönüş Açısı ──────────────────────────────────────────────────────
        ic = bolum("Dönüş Açısı (Rotation)", "🔄")

        self._sl_rotation = FFBSlider(
            ic, "Maksimum Dönüş Açısı",
            90, 1080, 900,
            "{:.0f}°", Renk.ACCENT
        )
        self._sl_rotation.pack(fill="x", pady=4)

        # Açı seçici butonları
        ac_f = ctk.CTkFrame(ic, fg_color="transparent")
        ac_f.pack(fill="x", pady=(4,0))
        ctk.CTkLabel(ac_f, text="Hızlı seçim:",
                     font=ctk.CTkFont(size=9),
                     text_color=Renk.METIN_YSL).pack(side="left")
        for ac in [270, 540, 720, 900, 1080]:
            ctk.CTkButton(
                ac_f, text=f"{ac}°",
                width=54, height=26,
                font=ctk.CTkFont(size=9, weight="bold"),
                fg_color=Renk.BG3,
                hover_color=Renk.ACCENT,
                command=lambda a=ac: self._sl_rotation.ayarla(float(a))
            ).pack(side="left", padx=2)

        # ── Hassasiyet & Deadzone ─────────────────────────────────────────────
        ic2 = bolum("Hassasiyet ve Deadzone", "🎯")

        self._sl_sens = FFBSlider(
            ic2, "Direksiyon Hassasiyeti",
            0.1, 3.0, 1.0,
            "{:.2f}x", Renk.ACCENT2
        )
        self._sl_sens.pack(fill="x", pady=4)

        self._sl_deadzone = FFBSlider(
            ic2, "Merkez Deadzone",
            0.0, 0.20, 0.02,
            "{:.0%}", Renk.SARI
        )
        self._sl_deadzone.pack(fill="x", pady=4)

        self._sl_sat = FFBSlider(
            ic2, "Maksimum Giriş Saturasyonu",
            0.5, 1.0, 1.0,
            "{:.0%}", Renk.TURUNCU
        )
        self._sl_sat.pack(fill="x", pady=4)

        # ── Lineerlik ─────────────────────────────────────────────────────────
        ic3 = bolum("Yanıt Eğrisi (Linearity)", "📈")

        self._sl_linear = FFBSlider(
            ic3, "Lineerlik  (1.0 = tam lineer)",
            0.5, 3.0, 1.0,
            "{:.2f}", Renk.YESIL
        )
        self._sl_linear.pack(fill="x", pady=4)

        ctk.CTkLabel(ic3,
                     text="< 1.0 = daha hassas merkez   |   > 1.0 = daha hassas uçlar",
                     font=ctk.CTkFont(size=8),
                     text_color=Renk.METIN_YSL).pack(anchor="w", pady=(0,4))

        # Eğri ön izleme (mini canvas)
        import tkinter as tk
        self._egri_cv = tk.Canvas(ic3, height=80, bg=Renk.BG,
                                   bd=0, highlightthickness=0)
        self._egri_cv.pack(fill="x", pady=4)
        self._sl_linear._sl.configure(
            command=lambda v: (
                self._sl_linear._degisti(v),
                self._egri_ciz(float(v))
            )
        )
        self.after(200, lambda: self._egri_ciz(1.0))

        # ── FFB Filtresi ──────────────────────────────────────────────────────
        ic4 = bolum("FFB Filtresi ve Frekans", "⚙️")

        self._sl_ffb_filter = FFBSlider(
            ic4, "Düşük Geçirgen Filtre (LPF)",
            0.0, 1.0, 0.3,
            "{:.0%}", Renk.ACCENT
        )
        self._sl_ffb_filter.pack(fill="x", pady=4)
        ctk.CTkLabel(ic4,
                     text="Yüksek değer = daha yumuşak/gecikmeli FFB",
                     font=ctk.CTkFont(size=8),
                     text_color=Renk.METIN_YSL).pack(anchor="w")

        self._sl_ffb_hz = FFBSlider(
            ic4, "FFB Güncelleme Hızı (Hz)",
            30, 200, 60,
            "{:.0f} Hz", Renk.ACCENT2
        )
        self._sl_ffb_hz.pack(fill="x", pady=(8,4))

        # Hız seçici
        hz_f = ctk.CTkFrame(ic4, fg_color="transparent")
        hz_f.pack(fill="x")
        ctk.CTkLabel(hz_f, text="Önayar:",
                     font=ctk.CTkFont(size=9),
                     text_color=Renk.METIN_YSL).pack(side="left")
        for hz in [30, 60, 100, 200]:
            ctk.CTkButton(
                hz_f, text=f"{hz} Hz",
                width=60, height=26,
                font=ctk.CTkFont(size=9, weight="bold"),
                fg_color=Renk.BG3,
                hover_color=Renk.ACCENT2,
                command=lambda h=hz: self._sl_ffb_hz.ayarla(float(h))
            ).pack(side="left", padx=2)

        # ── Kaydet ────────────────────────────────────────────────────────────
        alt_f = ctk.CTkFrame(sc, fg_color="transparent")
        alt_f.pack(fill="x", pady=(4,0))

        self._steer_kaydet_lbl = ctk.CTkLabel(
            alt_f, text="", font=ctk.CTkFont(size=9),
            text_color=Renk.YESIL)
        self._steer_kaydet_lbl.pack(side="right", padx=6)

        ctk.CTkButton(
            alt_f, text="Direksiyon Ayarlarını Kaydet",
            height=34, width=220,
            font=ctk.CTkFont(size=10, weight="bold"),
            fg_color=Renk.ACCENT,
            hover_color="#2563eb",
            command=self._steer_kaydet
        ).pack(side="right")

    def _egri_ciz(self, lineerlik: float):
        """Yanıt eğrisini mini canvas üzerine çiz."""
        cv = self._egri_cv
        cv.delete("all")
        w = cv.winfo_width() or 300
        h = 80
        import math as _m

        cv.create_line(0, h//2, w, h//2, fill=Renk.CERCEVE, width=1)
        cv.create_line(w//2, 0, w//2, h, fill=Renk.CERCEVE, width=1)
        cv.create_text(4, 4, text="Çıkış", fill=Renk.METIN_YSL,
                       font=("Segoe UI",7), anchor="nw")
        cv.create_text(w-4, h-4, text="Giriş", fill=Renk.METIN_YSL,
                       font=("Segoe UI",7), anchor="se")

        pts = []
        for i in range(w):
            x_n = (i / w) * 2 - 1           # -1 … +1
            y_n = _m.copysign(abs(x_n)**lineerlik, x_n)
            px  = i
            py  = int(h//2 - y_n * (h//2 - 6))
            pts.extend([px, py])

        if len(pts) >= 4:
            cv.create_line(*pts, fill=Renk.ACCENT, width=2, smooth=True)

    def _steer_kaydet(self):
        try:
            mevcut = {}
            if AYARDOS.exists():
                mevcut = json.loads(AYARDOS.read_text("utf-8"))
            mevcut["steering"] = {
                "rotation":    self._sl_rotation.deger,
                "sensitivity": self._sl_sens.deger,
                "deadzone":    self._sl_deadzone.deger,
                "saturation":  self._sl_sat.deger,
                "linearity":   self._sl_linear.deger,
                "lpf":         self._sl_ffb_filter.deger,
                "ffb_hz":      self._sl_ffb_hz.deger,
            }
            AYARDOS.write_text(json.dumps(mevcut, indent=2, ensure_ascii=False),
                                "utf-8")
            self._steer_kaydet_lbl.configure(text="✓ Kaydedildi!")
            self.after(2500, lambda: self._steer_kaydet_lbl.configure(text=""))
            LOG.info("Direksiyon ayarları kaydedildi.")
        except Exception as e:
            LOG.error("Direksiyon kayıt hatası: %s", e)

    # ═══════════════════════════════════════════════════════════════════════
    # Sekme: Kalibrasyon & Test
    # ═══════════════════════════════════════════════════════════════════════

    def _kalibrasyon_sekmesi(self, parent):
        """
        3 bölüm:
          A) Canlı Buton Göstergesi  – basmak ikonları yakar
          B) Direksiyon + Pedallar   – gerçek zamanlı progress bar'lar
          C) Sıfırla / Varsayılanlar
        """
        import tkinter as tk

        sc = ctk.CTkScrollableFrame(parent, fg_color="transparent")
        sc.pack(fill="both", expand=True, padx=6, pady=6)

        # ── A) Buton göstergesi ───────────────────────────────────────────────
        btn_kart = KartCerceve(sc, "Canlı Buton Testi  (fiziksel butona bas)", "🎮")
        btn_kart.pack(fill="x", pady=(0,8))

        # Buton layoutu — SideWinder FF2: 8 ana buton + 2 paddle + 4 hat
        BTN_LAYOUT = [
            # (label, btn_id, row, col, renk)
            ("L2",  8,  0, 0, Renk.ACCENT),
            ("LB",  4,  0, 1, Renk.METIN_YSL),
            ("⬆",  -1,  0, 2, Renk.METIN_YSL),   # hat up  (özel)
            ("RB",  5,  0, 3, Renk.METIN_YSL),
            ("R2",  9,  0, 4, Renk.ACCENT),
            ("X",   2,  1, 0, Renk.SARI),
            ("⬅",  -2,  1, 1, Renk.METIN_YSL),   # hat left
            ("▣",   6,  1, 2, Renk.METIN_YSL),    # Select
            ("➡",  -3,  1, 3, Renk.METIN_YSL),   # hat right
            ("Y",   3,  1, 4, Renk.YESIL),
            ("A",   0,  2, 0, Renk.KIRMIZI),
            ("⬇",  -4,  2, 1, Renk.METIN_YSL),   # hat down
            ("▶",   7,  2, 2, Renk.METIN_YSL),    # Start
            ("B",   1,  2, 3, Renk.ACCENT2),
            ("B1",  10, 2, 4, Renk.METIN_YSL),
        ]

        grid_f = ctk.CTkFrame(btn_kart.ic, fg_color="transparent")
        grid_f.pack(fill="x", pady=4)

        # Her sütun eşit genişlik
        for c in range(5): grid_f.grid_columnconfigure(c, weight=1)

        # btn_id → canvas widget referansı
        self._btn_widgets: dict[int, tk.Canvas] = {}

        for lbl, bid, row, col, renk in BTN_LAYOUT:
            cv = tk.Canvas(grid_f, width=52, height=52,
                           bg=Renk.BG3, bd=0, highlightthickness=0)
            cv.grid(row=row, column=col, padx=3, pady=3)

            # Arka plan daire
            cv.create_oval(4, 4, 48, 48,
                           fill=Renk.BG, outline=renk, width=2,
                           tags="bg")
            # Etiket
            cv.create_text(26, 26, text=lbl,
                           fill=renk,
                           font=("Consolas", 11, "bold"),
                           tags="lbl")
            self._btn_widgets[bid] = cv

        # ── B) Direksiyon + Pedallar ──────────────────────────────────────────
        inp_kart = KartCerceve(sc, "Gerçek Zamanlı Giriş Göstergesi", "📊")
        inp_kart.pack(fill="x", pady=(0,8))

        inp_ic = inp_kart.ic

        # Direksiyon barı (yatay)
        steer_f = ctk.CTkFrame(inp_ic, fg_color="transparent")
        steer_f.pack(fill="x", pady=(0,8))

        ctk.CTkLabel(steer_f, text="DİREKSİYON",
                     font=ctk.CTkFont("Segoe UI", 9, "bold"),
                     text_color=Renk.METIN_YSL,
                     width=90, anchor="w").pack(side="left")

        self._steer_canvas = tk.Canvas(steer_f, height=28, bg=Renk.BG3,
                                        bd=0, highlightthickness=0)
        self._steer_canvas.pack(side="left", fill="x", expand=True, padx=(6,6))

        self._steer_deg_lbl = ctk.CTkLabel(steer_f, text="0°",
                                            font=ctk.CTkFont("Consolas", 10, "bold"),
                                            text_color=Renk.ACCENT, width=48)
        self._steer_deg_lbl.pack(side="left")

        # Pedal barları (dikey) - Gas / Brake / Clutch
        pedal_f = ctk.CTkFrame(inp_ic, fg_color="transparent")
        pedal_f.pack(fill="x")

        self._pedal_cvs: dict[str, tk.Canvas] = {}
        self._pedal_lbls: dict[str, ctk.CTkLabel] = {}

        pedal_data = [
            ("GAS",   "G", Renk.YESIL,   2),   # axis 2 tipik gaz
            ("BRAKE", "B", Renk.KIRMIZI, 3),   # axis 3 tipik fren
            ("CLUTCH","C", Renk.SARI,    4),   # axis 4 tipik debriyaj
        ]
        for ad, kisa, renk, _ in pedal_data:
            col_f = ctk.CTkFrame(pedal_f, fg_color="transparent")
            col_f.pack(side="left", fill="x", expand=True, padx=6)

            ctk.CTkLabel(col_f, text=ad,
                         font=ctk.CTkFont("Segoe UI", 9, "bold"),
                         text_color=renk).pack()

            cv = tk.Canvas(col_f, width=40, height=120,
                           bg=Renk.BG3, bd=0, highlightthickness=0)
            cv.pack(pady=4)
            self._pedal_cvs[ad] = cv

            lbl = ctk.CTkLabel(col_f, text="0%",
                                font=ctk.CTkFont("Consolas", 9, "bold"),
                                text_color=renk)
            lbl.pack()
            self._pedal_lbls[ad] = lbl

        # ── C) Varsayılanlara Sıfırla ─────────────────────────────────────────
        sfr_kart = KartCerceve(sc, "Kalibrasyonu Sıfırla", "🔄")
        sfr_kart.pack(fill="x", pady=(0,4))

        sfr_ic = sfr_kart.ic

        ctk.CTkLabel(sfr_ic,
                     text="Tüm özel direksiyon, deadzone ve hassasiyet\n"
                          "ayarlarını fabrika değerlerine geri döndürür.",
                     font=ctk.CTkFont("Segoe UI", 9),
                     text_color=Renk.METIN_YSL,
                     justify="left").pack(anchor="w", pady=(0,8))

        alt_sfr = ctk.CTkFrame(sfr_ic, fg_color="transparent")
        alt_sfr.pack(fill="x")

        self._sfr_lbl = ctk.CTkLabel(alt_sfr, text="",
                                      font=ctk.CTkFont(size=9),
                                      text_color=Renk.YESIL)
        self._sfr_lbl.pack(side="right", padx=6)

        ctk.CTkButton(
            alt_sfr,
            text="⟳  Varsayılanlara Sıfırla",
            height=36, width=210,
            font=ctk.CTkFont("Segoe UI", 11, "bold"),
            fg_color=Renk.KIRMIZI,
            hover_color="#b91c1c",
            command=self._sifirla_varsayilan
        ).pack(side="left")

    def _sifirla_varsayilan(self):
        """Tüm slider'ları ve kaydedilmiş kalibrasyon değerlerini sıfırla."""
        if not FFB_OK or not self._ayar:
            return

        from sidewinder_ffb import Ayar as _Ayar
        yeni = _Ayar()

        # FFB slider'ları sıfırla
        try:
            self._sl_yay_max.ayarla(yeni.yay_max)
            self._sl_son.ayarla(yeni.son_taban)
            self._sl_g.ayarla(yeni.g_max)
            self._sl_son_g.ayarla(yeni.son_g)
        except Exception: pass

        # Direksiyon slider'ları sıfırla
        try:
            self._sl_rotation.ayarla(900.0)
            self._sl_sens.ayarla(1.0)
            self._sl_deadzone.ayarla(0.02)
            self._sl_sat.ayarla(1.0)
            self._sl_linear.ayarla(1.0)
            self._sl_ffb_filter.ayarla(0.3)
            self._sl_ffb_hz.ayarla(60.0)
            self._egri_ciz(1.0)
        except Exception: pass

        # Ayar nesnesini sıfırla
        for k, v in yeni.__dict__.items():
            setattr(self._ayar, k, v)

        # JSON dosyasını sil / temizle
        try:
            if AYARDOS.exists():
                mevcut = json.loads(AYARDOS.read_text("utf-8"))
                mevcut.pop("steering", None)
                mevcut.pop("btn_map", None)
                AYARDOS.write_text(
                    json.dumps(mevcut, indent=2, ensure_ascii=False), "utf-8")
        except Exception: pass

        self._ayar.kaydet()
        self._sfr_lbl.configure(text="✓ Sıfırlandı!")
        self.after(2500, lambda: self._sfr_lbl.configure(text=""))
        LOG.info("Tüm ayarlar varsayılanlara sıfırlandı.")

    # ═══════════════════════════════════════════════════════════════════════
    # Joystick polling thread  — SDL2 ham girdi, FFB motorundan bağımsız
    # ═══════════════════════════════════════════════════════════════════════

    def _js_poll_baslat(self):
        if not _SDL2:
            LOG.warning("SDL2 yüklü değil — joystick polling devre dışı.")
            return
        self._js_poll_stop.clear()
        self._js_poll_ip = threading.Thread(
            target=self._js_poll_thread, daemon=True, name="JSPoll")
        self._js_poll_ip.start()

    def _js_poll_thread(self):
        """
        Kök neden #1 düzeltmesi:
        SDL_JoystickUpdate() yerine SDL_PumpEvents() kullan.
        Haptic subsystem ile çakışmaz çünkü events ve haptic ayrı pipeline.

        Kök neden #2 düzeltmesi:
        sdl2'yi burada import etmek yerine modül düzeyindeki _SDL2
        flag'ini kontrol et ve doğrudan 'import sdl2' yap — bu
        zaten dosya başında yapılmış, tekrar import etmek güvenli.
        """
        # sdl2 zaten modül düzeyinde import edildi
        try:
            import sdl2 as _sdl
        except ImportError:
            LOG.error("JS poll: sdl2 import edilemedi.")
            return

        # SDL2 joystick subsystem'i başlat — eğer zaten çalışıyorsa no-op
        ret = _sdl.SDL_InitSubSystem(_sdl.SDL_INIT_JOYSTICK)
        if ret < 0:
            LOG.error("JS poll SDL_InitSubSystem hata: %s",
                      _sdl.SDL_GetError().decode())
            return

        # SideWinder'ı bul — önce ada göre, yoksa ilk joystick
        js = None
        n  = _sdl.SDL_NumJoysticks()
        LOG.info("JS poll: %d joystick listeleniyor.", n)
        for i in range(n):
            try:
                raw_name = _sdl.SDL_JoystickNameForIndex(i)
                ad = raw_name.decode() if raw_name else f"Joystick_{i}"
                LOG.info("  [%d] %s", i, ad)
                if js is None or "sidewinder" in ad.lower():
                    cand = _sdl.SDL_JoystickOpen(i)
                    if cand:
                        if js is not None:
                            _sdl.SDL_JoystickClose(js)
                        js = cand
                        if "sidewinder" in ad.lower():
                            LOG.info("JS poll: SideWinder secildi: %s", ad)
                            break
            except Exception as e:
                LOG.warning("JS poll joystick %d acma hatasi: %s", i, e)

        if js is None:
            LOG.warning("JS poll: Joystick bulunamadi — polling durdu.")
            return

        n_btns = _sdl.SDL_JoystickNumButtons(js)
        n_axes = _sdl.SDL_JoystickNumAxes(js)
        n_hats = _sdl.SDL_JoystickNumHats(js)
        LOG.info("JS poll: btns=%d axes=%d hats=%d", n_btns, n_axes, n_hats)

        INTERVAL = 0.008   # ~125 Hz — yeterince hızlı, CPU'yu yormaz

        while not self._js_poll_stop.is_set():
            t0 = time.monotonic()
            try:
                # PumpEvents haptic ile çakışmaz; JoystickUpdate da güvenli
                _sdl.SDL_PumpEvents()

                btns = {}
                for i in range(n_btns):
                    btns[i] = bool(_sdl.SDL_JoystickGetButton(js, i))

                axes = {}
                for i in range(n_axes):
                    raw = _sdl.SDL_JoystickGetAxis(js, i)
                    # raw: -32768 … +32767 → -1.0 … +1.0
                    axes[i] = raw / 32767.0

                hats = []
                for i in range(n_hats):
                    hats.append(int(_sdl.SDL_JoystickGetHat(js, i)))

                # Atomic dict swap — UI thread kısa süre lock'u alır
                with self._js_lock:
                    self._js_state = {
                        "btns": btns,
                        "axes": axes,
                        "hats": hats,
                    }

            except Exception as e:
                LOG.debug("JS poll döngü hatasi: %s", e)

            elapsed = time.monotonic() - t0
            rem = INTERVAL - elapsed
            if rem > 0:
                time.sleep(rem)

        try:
            _sdl.SDL_JoystickClose(js)
        except Exception:
            pass
        LOG.info("JS poll thread durdu.")

    # ═══════════════════════════════════════════════════════════════════════
    # Kalibrasyon widget güncelleme — UI thread
    # ═══════════════════════════════════════════════════════════════════════

    def _guncelle_kalibrasyon(self):
        """
        Kök neden #3 düzeltmesi — flash job yarış durumu tamamen kaldırıldı.

        Yeni yaklaşım:
          • Her frame'de mevcut durum doğrudan renklere yansıtılır.
          • Bırakma (release) anında 150ms highlight timer kurulur ama
            bu timer başka bir after() çağrısı YAPMAZ — sadece rengi söndürür.
          • Edge detection: önceki frame ile karşılaştır, yeni basma olaylarını
            logla / işle.
        """
        if not hasattr(self, "_btn_widgets"):
            return

        # ── JS durumunu oku ───────────────────────────────────────────────────
        with self._js_lock:
            snap = dict(self._js_state)

        btns = snap.get("btns", {})
        axes = snap.get("axes", {})
        hats = snap.get("hats", [])

        # ── Hat → sanal buton id ───────────────────────────────────────────────
        # SDL hat bitmask: 1=UP 2=RIGHT 4=DOWN 8=LEFT
        hat_basili: dict[int, bool] = {-1: False, -2: False,
                                        -3: False, -4: False}
        for hv in hats:
            if hv & 1: hat_basili[-1] = True   # UP
            if hv & 8: hat_basili[-2] = True   # LEFT
            if hv & 2: hat_basili[-3] = True   # RIGHT
            if hv & 4: hat_basili[-4] = True   # DOWN

        tum = {**btns, **hat_basili}

        # ── Buton widget renklerini direkt güncelle (flash job YOK) ───────────
        RENK_ON  = Renk.ACCENT      # basılı: mavi
        RENK_OFF = "#2d3748"        # bırakılmış: koyu gri
        YAZI_ON  = "#ffffff"
        YAZI_OFF = Renk.METIN_YSL

        for bid, cv in self._btn_widgets.items():
            basili    = tum.get(bid, False)
            prev      = self._js_prev_btns.get(bid, False)

            if basili:
                # Basılı: parlak mavi dolu daire
                try:
                    cv.itemconfig("bg",  fill=RENK_ON,  outline=RENK_ON)
                    cv.itemconfig("lbl", fill=YAZI_ON)
                except Exception:
                    pass
            elif prev and not basili:
                # Yeni bırakıldı: 180ms highlight (neon yeşil = "az önce basıldı")
                try:
                    cv.itemconfig("bg",  fill=Renk.YESIL, outline=Renk.YESIL)
                    cv.itemconfig("lbl", fill="#000000")
                except Exception:
                    pass
                # 180ms sonra söndür — lambda içinde cv'yi yakala
                def _sondur(c=cv):
                    try:
                        c.itemconfig("bg",  fill=RENK_OFF, outline=Renk.METIN_YSL)
                        c.itemconfig("lbl", fill=YAZI_OFF)
                    except Exception:
                        pass
                self.after(180, _sondur)
            else:
                # Bırakılmış ve highlight süresi geçmiş: karanlık
                try:
                    cv.itemconfig("bg",  fill=RENK_OFF, outline=Renk.METIN_YSL)
                    cv.itemconfig("lbl", fill=YAZI_OFF)
                except Exception:
                    pass

        # Önceki frame'i güncelle
        self._js_prev_btns = dict(tum)

        # ── Direksiyon barı ───────────────────────────────────────────────────
        if hasattr(self, "_steer_canvas"):
            steer_raw = axes.get(0, 0.0)
            max_deg   = getattr(self._sl_rotation, "deger", 900.0) \
                        if hasattr(self, "_sl_rotation") else 900.0
            deg = steer_raw * (max_deg / 2.0)

            cv = self._steer_canvas
            w  = cv.winfo_width() or 350
            h  = 28
            cx = w // 2
            cv.delete("all")

            # Track
            cv.create_rectangle(4, 8, w-4, h-8,
                                  fill=Renk.BG3, outline=Renk.CERCEVE)
            # Bar
            bar_w = int(abs(steer_raw) * (cx - 6))
            if bar_w > 0:
                bc = Renk.KIRMIZI if abs(steer_raw) > 0.85 else Renk.ACCENT
                if steer_raw >= 0:
                    cv.create_rectangle(cx, 10, cx + bar_w, h-10,
                                         fill=bc, outline="")
                else:
                    cv.create_rectangle(cx - bar_w, 10, cx, h-10,
                                         fill=bc, outline="")
            # Merkez çizgisi
            cv.create_line(cx, 5, cx, h-5, fill=Renk.METIN_YSL, width=1)
            # Yazı
            cv.create_text(cx, h // 2,
                           text=f"{deg:+.0f}°",
                           fill=Renk.METIN,
                           font=("Consolas", 9, "bold"))
            try:
                self._steer_deg_lbl.configure(text=f"{deg:+.0f}°")
            except Exception:
                pass

        # ── Pedal barları ─────────────────────────────────────────────────────
        PEDAL_AX   = {"GAS": 2, "BRAKE": 3, "CLUTCH": 4}
        PEDAL_RENK = {"GAS": Renk.YESIL, "BRAKE": Renk.KIRMIZI,
                       "CLUTCH": Renk.SARI}

        for ad, ax_id in PEDAL_AX.items():
            if ad not in getattr(self, "_pedal_cvs", {}):
                continue
            cv   = self._pedal_cvs[ad]
            raw  = axes.get(ax_id, -1.0)
            # Normalize: büyük çoğunluk direksiyon -1=bırak +1=bas
            pct  = max(0.0, min(1.0, (raw + 1.0) / 2.0))
            renk = PEDAL_RENK[ad]

            W, H = 40, 120
            cv.delete("all")
            # Arka plan kanalı
            cv.create_rectangle(8, 4, W-8, H-4,
                                  fill=Renk.BG3, outline=Renk.CERCEVE)
            # Doldurulan kısım (alttan)
            bar_h = int(pct * (H - 12))
            if bar_h > 0:
                cv.create_rectangle(10, H-6-bar_h, W-10, H-6,
                                     fill=renk, outline="")
            # Yüzde yazısı
            cv.create_text(W//2, H//2,
                           text=f"{int(pct*100)}",
                           fill=Renk.METIN,
                           font=("Consolas", 8, "bold"))
            try:
                self._pedal_lbls[ad].configure(text=f"{int(pct*100)}%")
            except Exception:
                pass

    # ═══════════════════════════════════════════════════════════════════════
    # Canlı güncelleme döngüsü
    # ═══════════════════════════════════════════════════════════════════════

    def _guncelle_dongusu(self):
        try:
            self._guncelle()
            self._guncelle_kalibrasyon()
            self._guncelle_emulasyon()
        except Exception as e:
            LOG.debug("Güncelleme hatası: %s", e)
        self.after(50, self._guncelle_dongusu)   # 20 fps — yeterince akıcı

    def _guncelle(self):
        if not FFB_OK:
            return

        # Telemetri
        k = self._alici.son if self._alici else None
        if k:
            self._metrik_lbls["m_yanal"].configure(
                text=f"{k.yanal:+.3f} G",
                text_color=Renk.KIRMIZI if abs(k.yanal) > (self._ayar.g_max * 0.8)
                else Renk.METIN)
            self._metrik_lbls["m_boysal"].configure(text=f"{k.boysal:+.3f} G")
            self._metrik_lbls["m_hiz"].configure(
                text=f"{k.hiz * 3.6:.1f} km/h")
            self._metrik_lbls["m_zemin"].configure(text=k.zemin.name)
            self._metrik_lbls["m_yaw"].configure(
                text=f"{k.yaw:.3f} r/s")
            self._metrik_lbls["m_kaynak"].configure(
                text=k.kaynak,
                text_color=Renk.YESIL)
            self._g_bar.ciz(k.yanal, self._ayar.g_max)
        else:
            for lbl in self._metrik_lbls.values():
                lbl.configure(text="---", text_color=Renk.METIN_YSL)
            self._g_bar.ciz(0.0)

        # FFB güç barları
        if self._motor:
            for ad, key in [("yay","yay"),("son","son"),("sin","sin")]:
                yuva = self._motor._yuv.get(key)
                val  = max(0.0, min(1.0, yuva.guc)) if yuva and yuva.guc > -98 else 0.0
                self._ffb_bars[ad].set(val)

        # Log kutusu
        try:
            if LOGDOS.exists():
                satirlar = LOGDOS.read_text(
                    encoding="utf-8", errors="replace").split("\n")
                son = "\n".join(satirlar[-20:])
                self._log_box.configure(state="normal")
                self._log_box.delete("0.0", "end")
                self._log_box.insert("0.0", son)
                self._log_box.configure(state="disabled")
                self._log_box.see("end")
        except Exception:
            pass

    # ═══════════════════════════════════════════════════════════════════════
    # Sekme: Gamepad Emülasyon
    # ═══════════════════════════════════════════════════════════════════════

    def _emulasyon_sekmesi(self, parent):
        """
        Hybrid Mode — Direksiyonu Xbox 360 Gamepad olarak göster.
        3 bölüm:
          A) Toggle + Kalibrasyon (merkez, limit öğretme)
          B) Eksen monitor (progress bar'lar — "oyuna ne gönderiyorum")
          C) Dual analog crosshair + parametreler
        """
        import tkinter as tk

        sc = ctk.CTkScrollableFrame(parent, fg_color="transparent")
        sc.pack(fill="both", expand=True, padx=8, pady=8)

        def bolum(baslik, ikon=""):
            k = KartCerceve(sc, baslik, ikon)
            k.pack(fill="x", pady=(0,8))
            return k.ic

        # ── A) Hybrid Mode toggle + kalibrasyon ───────────────────────────────
        ic_hdr = bolum("Hybrid Steering Mode — Xbox 360 Emülasyonu", "🎮")

        if not VGAMEPAD_OK:
            ctk.CTkLabel(ic_hdr,
                text="vgamepad yuklu degil! Calistirin:\n"
                     "  py -3.12 -m pip install vgamepad\n\n"
                     "ViGEmBus kernel surucu de gerekli:\n"
                     "  github.com/nefarius/ViGEmBus/releases",
                font=ctk.CTkFont("Consolas", 10),
                text_color=Renk.SARI,
                justify="left").pack(anchor="w", padx=4, pady=4)
        else:
            ctk.CTkLabel(ic_hdr,
                text="Mod AKTIF iken oyun, direksiyon yerine standart\n"
                     "Xbox 360 gamepad gorur. Kalibre etmeden calısır.",
                font=ctk.CTkFont("Segoe UI", 9),
                text_color=Renk.METIN_YSL).pack(anchor="w", pady=(0,6))

        sw_f = ctk.CTkFrame(ic_hdr, fg_color="transparent")
        sw_f.pack(fill="x")

        self._emul_sw = ctk.CTkSwitch(
            sw_f, text="Gamepad Emülasyonunu Aktifle",
            font=ctk.CTkFont("Segoe UI", 11, "bold"),
            progress_color=Renk.YESIL,
            command=self._emul_toggle,
            state="normal" if VGAMEPAD_OK else "disabled")
        self._emul_sw.pack(side="left")

        self._emul_badge = ctk.CTkLabel(
            sw_f, text="KAPALI",
            font=ctk.CTkFont("Consolas", 10, "bold"),
            text_color=Renk.METIN_YSL, width=70)
        self._emul_badge.pack(side="left", padx=10)

        # ── Kalibrasyon alt bölümü ────────────────────────────────────────────
        calib_f = ctk.CTkFrame(ic_hdr, fg_color=Renk.BG3, corner_radius=8)
        calib_f.pack(fill="x", pady=(10,0))

        ctk.CTkLabel(calib_f,
            text="Direksiyon Kalibrasyonu",
            font=ctk.CTkFont("Segoe UI", 10, "bold"),
            text_color=Renk.ACCENT).pack(anchor="w", padx=10, pady=(8,4))

        ctk.CTkLabel(calib_f,
            text="1) Direksiyonu tam merkeze getir → 'Merkezi Kaydet'\n"
                 "2) Tam SOLA sur → 'Sol Limiti Kaydet'\n"
                 "3) Tam SAGA sur → 'Sag Limiti Kaydet'",
            font=ctk.CTkFont("Segoe UI", 8),
            text_color=Renk.METIN_YSL,
            justify="left").pack(anchor="w", padx=10)

        self._calib_status_lbl = ctk.CTkLabel(
            calib_f, text="Kalibrasyon: Yapilmadi",
            font=ctk.CTkFont("Consolas", 9, "bold"),
            text_color=Renk.SARI)
        self._calib_status_lbl.pack(anchor="w", padx=10, pady=(4,0))

        btns_f = ctk.CTkFrame(calib_f, fg_color="transparent")
        btns_f.pack(fill="x", padx=8, pady=8)

        for txt, cmd, renk in [
            ("Merkezi Kaydet",   self._calib_merkez,     Renk.ACCENT),
            ("Sol Limiti Kaydet",self._calib_sol_limit,   Renk.KIRMIZI),
            ("Sag Limiti Kaydet",self._calib_sag_limit,   Renk.YESIL),
            ("Sifirla",          self._calib_sifirla,     Renk.METIN_YSL),
        ]:
            ctk.CTkButton(
                btns_f, text=txt, height=30,
                font=ctk.CTkFont(size=9, weight="bold"),
                fg_color=Renk.BG, hover_color=renk,
                border_color=renk, border_width=1,
                command=cmd
            ).pack(side="left", padx=3)

        # Ham axis değeri göstergesi (kalibrasyon sırasında yardımcı)
        self._calib_raw_lbl = ctk.CTkLabel(
            calib_f, text="Ham Axis 0: 0.000",
            font=ctk.CTkFont("Consolas", 9),
            text_color=Renk.METIN_YSL)
        self._calib_raw_lbl.pack(anchor="w", padx=10, pady=(0,8))

        # ── B) Sanal Gamepad Çıktı Monitörü ──────────────────────────────────
        ic_mon = bolum("Sanal Gamepad Cikti Monitoru  (oyuna giden veri)", "📊")

        # "Oyuna ne gidiyor" tablo başlığı
        ctk.CTkLabel(ic_mon,
            text="Direksiyonu cevir veya pedala bas — barlar anlık degisir.",
            font=ctk.CTkFont("Segoe UI", 8),
            text_color=Renk.METIN_YSL).pack(anchor="w", pady=(0,6))

        # Progress bar'lar
        self._vgp_bars: dict[str, ctk.CTkProgressBar] = {}
        self._vgp_val_lbls: dict[str, ctk.CTkLabel] = {}

        monitor_items = [
            # (etiket,          key,          renk,         fmt)
            ("Sol Analog X  (Direksiyon)", "steer_norm", Renk.ACCENT,  "{:+.3f}"),
            ("Sag Trigger RT (Gaz)",       "gas_pct",    Renk.YESIL,  "{:.0%}"),
            ("Sol Trigger LT (Fren)",      "brk_pct",    Renk.KIRMIZI, "{:.0%}"),
            ("Sol Analog Y  (Debriyaj)",   "clutch_pct", Renk.SARI,   "{:.0%}"),
            ("Sag Analog X  (Yaw)",        "yaw_norm",   Renk.ACCENT2, "{:+.3f}"),
        ]

        for etiket, key, renk, fmt in monitor_items:
            row = ctk.CTkFrame(ic_mon, fg_color=Renk.BG3, corner_radius=6)
            row.pack(fill="x", pady=2)

            ctk.CTkLabel(row, text=etiket,
                         font=ctk.CTkFont("Consolas", 9),
                         text_color=Renk.METIN_YSL,
                         width=200, anchor="w").pack(side="left", padx=8, pady=6)

            pb = ctk.CTkProgressBar(row, height=10,
                                     progress_color=renk,
                                     fg_color=Renk.BG,
                                     width=160)
            pb.set(0.5)  # başlangıç: merkez
            pb.pack(side="left", padx=4)
            self._vgp_bars[key] = pb

            val_lbl = ctk.CTkLabel(row, text="0.000",
                                    font=ctk.CTkFont("Consolas", 9, "bold"),
                                    text_color=renk, width=56, anchor="e")
            val_lbl.pack(side="left", padx=6)
            self._vgp_val_lbls[key] = val_lbl

        # ── C) Dual Analog Crosshair + parametreler ───────────────────────────
        ic_cross = bolum("Analog Cubuk Goruntuleyici (Crosshair)", "🕹️")

        cross_f = ctk.CTkFrame(ic_cross, fg_color="transparent")
        cross_f.pack(fill="x")

        self._cross_cvs:  dict[str, tk.Canvas]         = {}
        self._cross_lbls: dict[str, ctk.CTkLabel]       = {}

        for ad, renk in [("SOL ANALOG", Renk.ACCENT),
                         ("SAG ANALOG", Renk.ACCENT2)]:
            col = ctk.CTkFrame(cross_f, fg_color="transparent")
            col.pack(side="left", fill="x", expand=True, padx=6)

            ctk.CTkLabel(col, text=ad,
                         font=ctk.CTkFont("Segoe UI", 9, "bold"),
                         text_color=renk).pack()

            cv = tk.Canvas(col, width=130, height=130, bg=Renk.BG3,
                           bd=0, highlightthickness=2,
                           highlightbackground=renk)
            cv.pack(pady=4)
            self._cross_cvs[ad] = cv

            lbl = ctk.CTkLabel(col, text="X: 0.000  Y: 0.000",
                               font=ctk.CTkFont("Consolas", 9),
                               text_color=Renk.METIN_YSL)
            lbl.pack()
            self._cross_lbls[ad] = lbl

        # Parametre slider'ları
        ic_par = bolum("Emulator Parametreleri", "⚙️")

        self._sl_emul_dz = FFBSlider(
            ic_par, "Deadzone (Olu Bolge)",
            0.0, 0.30, 0.05, "{:.0%}", Renk.SARI,
            degisti_cb=lambda v: setattr(self, "_emul_deadzone", v))
        self._sl_emul_dz.pack(fill="x", pady=4)

        self._sl_emul_ss = FFBSlider(
            ic_par, "Direksiyon Hassasiyeti",
            0.1, 3.0, 1.0, "{:.2f}x", Renk.ACCENT,
            degisti_cb=lambda v: setattr(self, "_emul_sens_steer", v))
        self._sl_emul_ss.pack(fill="x", pady=4)

        self._sl_emul_sp = FFBSlider(
            ic_par, "Pedal Hassasiyeti",
            0.1, 2.0, 1.0, "{:.2f}x", Renk.ACCENT2,
            degisti_cb=lambda v: setattr(self, "_emul_sens_ped", v))
        self._sl_emul_sp.pack(fill="x", pady=4)

        self._emul_invert_sw = ctk.CTkSwitch(
            ic_par, text="Direksiyonu Tersine Cevir",
            font=ctk.CTkFont(size=10),
            command=lambda: setattr(self, "_emul_invert_steer",
                                    self._emul_invert_sw.get() == 1))
        self._emul_invert_sw.pack(anchor="w", pady=(4, 0))

    # ── Kalibrasyon işlemleri ──────────────────────────────────────────────────

    def _calib_raw_axis(self) -> float:
        with self._js_lock:
            return self._js_state.get("axes", {}).get(0, 0.0)

    def _calib_merkez(self):
        raw = self._calib_raw_axis()
        self._calib_center = raw
        self._calib_guncelle_lbl()
        LOG.info("Kalibrasyon merkez: %.4f", raw)

    def _calib_sol_limit(self):
        raw = self._calib_raw_axis()
        self._calib_min = raw
        self._calib_guncelle_lbl()
        LOG.info("Kalibrasyon sol limit: %.4f", raw)

    def _calib_sag_limit(self):
        raw = self._calib_raw_axis()
        self._calib_max = raw
        self._calib_guncelle_lbl()
        LOG.info("Kalibrasyon sag limit: %.4f", raw)

    def _calib_sifirla(self):
        self._calib_center = 0.0
        self._calib_min    = -1.0
        self._calib_max    =  1.0
        self._calib_kayitli = False
        self._calib_guncelle_lbl()
        LOG.info("Kalibrasyon sifirlanadi.")

    def _calib_guncelle_lbl(self):
        try:
            both_limits = (self._calib_min < -0.5 or self._calib_max > 0.5)
            self._calib_kayitli = both_limits
            self._calib_status_lbl.configure(
                text=f"Merkez:{self._calib_center:+.3f}  "
                     f"Sol:{self._calib_min:+.3f}  "
                     f"Sag:{self._calib_max:+.3f}",
                text_color=Renk.YESIL if self._calib_kayitli else Renk.SARI)
        except Exception:
            pass

    def _calib_uygula(self, raw: float) -> float:
        """Ham axis değerini kalibrasyon ile normalize et → -1.0…+1.0."""
        raw -= self._calib_center
        if raw >= 0:
            span = max(self._calib_max - self._calib_center, 0.01)
            return max(-1.0, min(1.0, raw / span))
        else:
            span = max(self._calib_center - self._calib_min, 0.01)
            return max(-1.0, min(1.0, raw / span))

    # ── Emülatör toggle / başlat / durdur ────────────────────────────────────

    def _emul_toggle(self):
        if self._emul_sw.get() == 1:
            self._emul_baslat()
        else:
            self._emul_durdur()

    def _emul_baslat(self):
        if self._emul_aktif or not VGAMEPAD_OK:
            return
        try:
            self._emul_gamepad = vg.VX360Gamepad()
            self._emul_stop.clear()
            self._emul_ip = threading.Thread(
                target=self._emul_thread, daemon=True, name="EmulThread")
            self._emul_ip.start()
            self._emul_aktif = True
            self._emul_badge.configure(text="AKTIF", text_color=Renk.YESIL)
            LOG.info("Gamepad emulasyonu basladi.")
        except Exception as e:
            LOG.error("Emulator baslatilamadi: %s", e)
            try: self._emul_sw.deselect()
            except Exception: pass
            self._emul_badge.configure(text="HATA", text_color=Renk.KIRMIZI)

    def _emul_durdur(self):
        self._emul_stop.set()
        if self._emul_ip:
            self._emul_ip.join(timeout=2.0)
            self._emul_ip = None
        try:
            if self._emul_gamepad:
                self._emul_gamepad.reset()
                self._emul_gamepad.update()
                self._emul_gamepad = None
        except Exception:
            pass
        self._emul_aktif = False
        try:
            self._emul_badge.configure(text="KAPALI",
                                        text_color=Renk.METIN_YSL)
        except Exception:
            pass
        LOG.info("Gamepad emulasyonu durduruldu.")

    def _emul_thread(self):
        """
        125 Hz: JS axis → kalibrasyon uygula → vgamepad'e yaz.
        Aynı zamanda _vgp_snapshot'ı günceller → UI monitor onu okur.
        """
        INTERVAL = 0.008

        def clamp(v, lo=-1.0, hi=1.0):
            return max(lo, min(hi, v))

        def dz_apply(v, dz):
            if abs(v) < dz: return 0.0
            s = 1.0 if v > 0 else -1.0
            return s * (abs(v) - dz) / (1.0 - dz + 1e-9)

        def to_short(v):   return int(clamp(v) * 32767)
        def to_trig(v):    return int(max(0.0, min(1.0, v)) * 255)
        def ped_pct(raw):  return max(0.0, min(1.0, (raw + 1.0) / 2.0))

        gp = self._emul_gamepad

        while not self._emul_stop.is_set():
            t0 = time.monotonic()
            try:
                with self._js_lock:
                    axes = dict(self._js_state.get("axes", {}))

                dz  = self._emul_deadzone
                ss  = self._emul_sens_steer
                sp  = self._emul_sens_ped
                inv = -1.0 if self._emul_invert_steer else 1.0

                # Direksiyon: kalibrasyon uygula → deadzone → hassasiyet
                raw_s     = axes.get(0, 0.0) * inv
                norm_s    = self._calib_uygula(raw_s * inv) * inv
                steer_out = clamp(dz_apply(norm_s, dz) * ss)
                lx        = to_short(steer_out)

                # Pedallar
                gas_p   = ped_pct(axes.get(2, -1.0)) * sp
                brk_p   = ped_pct(axes.get(3, -1.0)) * sp
                clt_p   = ped_pct(axes.get(4, -1.0)) * sp
                yaw_n   = clamp(axes.get(5, 0.0))

                rt = to_trig(gas_p)
                lt = to_trig(brk_p)
                ly = to_short(clamp(clt_p * 2.0 - 1.0))
                rx = to_short(yaw_n)

                gp.left_joystick(lx, ly)
                gp.right_joystick(rx, 0)
                gp.left_trigger(value=lt)
                gp.right_trigger(value=rt)
                gp.update()

                # Snapshot → UI monitor
                with self._vgp_snapshot_lock:
                    self._vgp_snapshot = {
                        "lx": lx, "ly": ly, "rx": rx, "ry": 0,
                        "lt": lt, "rt": rt,
                        "steer_norm":  steer_out,
                        "gas_pct":     min(1.0, gas_p),
                        "brk_pct":     min(1.0, brk_p),
                        "clutch_pct":  min(1.0, clt_p),
                        "yaw_norm":    yaw_n,
                    }

            except Exception as e:
                LOG.debug("Emul thread hata: %s", e)

            rem = INTERVAL - (time.monotonic() - t0)
            if rem > 0:
                time.sleep(rem)

    # ── Emülasyon UI güncelleme (UI thread, 20 fps) ───────────────────────────

    def _guncelle_emulasyon(self):
        if not hasattr(self, "_cross_cvs"):
            return

        # Ham axis oku (her zaman göster)
        with self._js_lock:
            axes = dict(self._js_state.get("axes", {}))

        raw0 = axes.get(0, 0.0)

        # Kalibrasyon ham göstergesi
        try:
            self._calib_raw_lbl.configure(text=f"Ham Axis 0: {raw0:+.4f}")
        except Exception:
            pass

        # ── Çıktı monitor bar'ları ────────────────────────────────────────────
        if hasattr(self, "_vgp_bars"):
            with self._vgp_snapshot_lock:
                snap = dict(self._vgp_snapshot)

            # Steer: -1…+1 → bar 0…1 (merkez=0.5)
            steer_n = snap.get("steer_norm", 0.0)
            self._vgp_bar_ayarla("steer_norm", (steer_n + 1.0) / 2.0,
                                  f"{steer_n:+.3f}")
            # Gaz, fren, debriyaj: 0…1 → bar 0…1
            for key, fmt in [("gas_pct",  "{:.0%}"),
                              ("brk_pct",  "{:.0%}"),
                              ("clutch_pct", "{:.0%}"),
                              ("yaw_norm", "{:+.3f}")]:
                v = snap.get(key, 0.0)
                bar_v = (v + 1.0) / 2.0 if "norm" in key else v
                self._vgp_bar_ayarla(key, bar_v, fmt.format(v))

        # ── Crosshair ────────────────────────────────────────────────────────
        # Sol analog: kalibrasyon uygulanmış direksiyon değeri
        sol_x = self._calib_uygula(raw0) if self._calib_kayitli else raw0
        sol_y = axes.get(1, 0.0)
        sag_x = axes.get(5, 0.0)
        sag_y = axes.get(6, 0.0)

        for (ad, ax, ay), renk in [
            (("SOL ANALOG", sol_x, sol_y), Renk.ACCENT),
            (("SAG ANALOG", sag_x, sag_y), Renk.ACCENT2),
        ]:
            if ad not in self._cross_cvs:
                continue
            cv = self._cross_cvs[ad]
            cv.delete("all")
            W = H = 130
            cx = cy = W // 2

            # Izgara
            cv.create_line(0, cy, W, cy, fill=Renk.CERCEVE, width=1)
            cv.create_line(cx, 0, cx, H, fill=Renk.CERCEVE, width=1)

            # Deadzone çemberi
            dz   = getattr(self, "_emul_deadzone", 0.05)
            dz_r = int(dz * cx)
            if dz_r > 0:
                cv.create_oval(cx-dz_r, cy-dz_r, cx+dz_r, cy+dz_r,
                               outline=Renk.SARI, width=1, dash=(3, 3))

            # Nokta
            px = int(cx + ax * (cx - 8))
            py = int(cy - ay * (cy - 8))
            in_dz  = (ax**2 + ay**2) < dz**2
            dot_c  = Renk.SARI if in_dz else renk

            # İz çizgisi (merkeze)
            cv.create_line(cx, cy, px, py, fill=dot_c, width=1,
                           dash=(2, 3))
            # Crosshair
            cv.create_line(px-7, py, px+7, py, fill=dot_c, width=2)
            cv.create_line(px, py-7, px, py+7, fill=dot_c, width=2)
            cv.create_oval(px-9, py-9, px+9, py+9,
                           outline=dot_c, width=2)
            if not in_dz:
                cv.create_oval(px-3, py-3, px+3, py+3,
                               fill=dot_c, outline="")

            try:
                self._cross_lbls[ad].configure(
                    text=f"X: {ax:+.3f}  Y: {ay:+.3f}")
            except Exception:
                pass

    def _vgp_bar_ayarla(self, key: str, val: float, yazi: str):
        """Progress bar ve değer etiketini thread-safe güncelle."""
        try:
            self._vgp_bars[key].set(max(0.0, min(1.0, val)))
            self._vgp_val_lbls[key].configure(text=yazi)
        except Exception:
            pass

    # ═══════════════════════════════════════════════════════════════════════
    # Tray
    # ═══════════════════════════════════════════════════════════════════════

    def _gizle(self):
        self.withdraw()
        if TRAY_OK and self._tray_ikon is None:
            self._tray_olustur()

    def _goster(self, *_):
        self.after(0, self.deiconify)
        self.after(0, self.lift)
        self.after(0, self.focus_force)

    def _tray_olustur(self):
        try:
            ikon = self._tray_ikon_ciz()
            menu = pystray.Menu(
                pystray.MenuItem(
                    f"{APP_ADI}  v{SURUM}", None, enabled=False),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Pencereyi Aç", self._goster, default=True),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem(
                    lambda _: "Durdur" if self._cal else "Başlat",
                    lambda *_: self.after(0, self._togel)
                ),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Çıkış", self._tam_kapat),
            )
            self._tray_ikon = pystray.Icon(APP_ADI, ikon, APP_ADI, menu)
            threading.Thread(target=self._tray_ikon.run,
                             daemon=True, name="Tray").start()
        except Exception as e:
            LOG.warning("Tray oluşturulamadı: %s", e)

    def _tray_ikon_ciz(self) -> Image.Image:
        renk = (50, 220, 90) if self._cal else (130, 130, 130)
        S    = 256
        im   = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        d    = ImageDraw.Draw(im)
        p    = max(int(S * 0.07), 2)
        kl   = max(int(S * 0.09), 1)
        d.ellipse([p, p, S-p, S-p], outline=renk, width=kl)
        hr = S * 0.14; cx = cy = S // 2
        d.ellipse([cx-hr, cy-hr, cx+hr, cy+hr], fill=renk)
        r = S//2 - p - kl//2
        for ag in [90, 210, 330]:
            rad = math.radians(ag)
            ex  = cx + r * math.cos(rad)
            ey  = cy - r * math.sin(rad)
            d.line([cx, cy, ex, ey], fill=renk, width=max(kl-1, 1))
        return im.resize((64, 64), Image.LANCZOS)

    def _tam_kapat(self, *_):
        self._emul_durdur()
        self._js_poll_stop.set()
        if self._js_poll_ip:
            self._js_poll_ip.join(timeout=1.0)
        self._durdur()
        if self._tray_ikon:
            try: self._tray_ikon.stop()
            except Exception: pass
        self.after(0, self.destroy)


# ════════════════════════════════════════════════════════════════════════════
# Giriş noktası
# ════════════════════════════════════════════════════════════════════════════

def main():
    if not CTK_OK:
        print("customtkinter yuklu degil!")
        print("pip install customtkinter")
        sys.exit(1)

    app = SideWinderApp()
    try:
        app.mainloop()
    except KeyboardInterrupt:
        pass
    finally:
        try:
            app._durdur()
        except Exception:
            pass


if __name__ == "__main__":
    main()

"""
sidewinder_ffb.py  -  SideWinder FFB Wrapper  v3.0
Yenilikler:
  - Tam ayarlar penceresi (tkinter - ek kurulum gerekmez)
  - Canli telemetri goruntusu
  - FFB kuvvet sliderları
  - Tray menu: 'Ayarlar', 'Baslat/Durdur', 'Cikis'
"""

import sys, os, time, json, math, socket, struct
import logging, logging.handlers, threading, pathlib
from dataclasses import dataclass, field
from enum        import IntEnum
from typing      import Optional, List, Dict, Callable

# ── Opsiyonel kutuphaneler ────────────────────────────────────────────────────
_SDL2 = False
try:
    import sdl2, sdl2.haptic  # noqa
    _SDL2 = True
except ImportError: pass

_TRAY = False
try:
    import pystray
    from PIL import Image, ImageDraw
    _TRAY = True
except ImportError: pass

# tkinter her Python kurulumunda gelir - ek kurulum gerekmez
_TK = False
try:
    import tkinter as tk
    from tkinter import ttk, messagebox
    _TK = True
except ImportError: pass

# ── Sabitler ──────────────────────────────────────────────────────────────────
AD      = "SideWinder FFB"
SURUM   = "3.0"
PORT    = 20777
HZ      = 60
SDLMAX  = 32767
SINF    = 0xFFFFFFFF
G_MS2   = 9.80665

PROJE   = pathlib.Path(__file__).parent.resolve()
APPDIR  = pathlib.Path(os.environ.get("APPDATA","~")).expanduser() / "SideWinderFFB"
APPDIR.mkdir(parents=True, exist_ok=True)
LOGDOS  = APPDIR / "sidewinder_ffb.log"
AYARDOS = APPDIR / "ayarlar.json"

# ── Log ───────────────────────────────────────────────────────────────────────
def _log_kur():
    r = logging.getLogger()
    r.setLevel(logging.DEBUG)
    fmt = logging.Formatter("%(asctime)s [%(name)-10s] %(levelname)-7s %(message)s",
                            "%Y-%m-%d %H:%M:%S")
    fh = logging.handlers.RotatingFileHandler(
        LOGDOS, maxBytes=2*1024*1024, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    r.addHandler(fh)
    if not getattr(sys,"frozen",False):
        ch = logging.StreamHandler(sys.stdout)
        ch.setFormatter(fmt)
        ch.setLevel(logging.INFO)
        r.addHandler(ch)

_log_kur()
LOG = logging.getLogger("ana")

# ── Ayarlar ───────────────────────────────────────────────────────────────────
@dataclass
class Ayar:
    udp_port:     int   = 20777
    g_max:        float = 3.0
    yay_min:      float = 0.05
    yay_max:      float = 0.88
    son_taban:    float = 0.20
    son_g:        float = 0.38
    son_hiz:      float = 0.32
    hiz_ref:      float = 83.0
    zaman_asimi:  float = 3.0
    # Yeni: kullanici dostu isimler ile UI gosterilir
    @classmethod
    def yukle(cls):
        try:
            if AYARDOS.exists():
                d = json.loads(AYARDOS.read_text("utf-8"))
                o = cls()
                for k,v in d.items():
                    if hasattr(o,k): setattr(o,k,v)
                return o
        except Exception as e:
            LOG.warning("Ayar yuklenemedi: %s", e)
        return cls()

    def kaydet(self):
        try:
            AYARDOS.write_text(
                json.dumps(self.__dict__,indent=2,ensure_ascii=False),"utf-8")
        except Exception as e:
            LOG.warning("Ayar kaydedilemedi: %s", e)

# ── Zemin ─────────────────────────────────────────────────────────────────────
class Zemin(IntEnum):
    ASFALT=0; CAKIL=1; CIM=2; TOPRAK=3; KUM=4
    BUZ=5; ARNAVUT=6; BILINMEZ=99
    @classmethod
    def forza(cls,v):
        return{1:cls.ASFALT,2:cls.ASFALT,3:cls.CAKIL,4:cls.TOPRAK,
               5:cls.CIM,6:cls.KUM,7:cls.BUZ,8:cls.ARNAVUT}.get(v,cls.BILINMEZ)
    @classmethod
    def f1(cls,v):
        return{0:cls.ASFALT,1:cls.CAKIL,2:cls.CIM,
               3:cls.TOPRAK,4:cls.KUM}.get(v,cls.BILINMEZ)

# ── Telemetri ─────────────────────────────────────────────────────────────────
@dataclass
class Kare:
    yanal:float=0.0; boysal:float=0.0; hiz:float=0.0; yaw:float=0.0
    z_sl:Zemin=Zemin.BILINMEZ; z_sr:Zemin=Zemin.BILINMEZ
    z_al:Zemin=Zemin.BILINMEZ; z_ar:Zemin=Zemin.BILINMEZ
    kaynak:str="?"; t:float=field(default_factory=time.monotonic)
    @property
    def abs_yanal(self): return abs(self.yanal)
    @property
    def hiz_kmh(self): return self.hiz*3.6
    @property
    def zemin(self):
        onc=[Zemin.BUZ,Zemin.CIM,Zemin.TOPRAK,Zemin.KUM,
             Zemin.CAKIL,Zemin.ARNAVUT,Zemin.ASFALT,Zemin.BILINMEZ]
        ws={self.z_sl,self.z_sr,self.z_al,self.z_ar}
        for z in onc:
            if z in ws: return z
        return Zemin.BILINMEZ
    @property
    def kir(self): return self.zemin not in(Zemin.ASFALT,Zemin.BILINMEZ)

def _forza(d):
    try:
        if len(d)<232: return None
        f=struct.unpack_from("<iIffffffffffffffffff",d,0)
        hiz=(f[8]**2+f[9]**2+f[10]**2)**0.5
        k=Kare(yanal=f[5]/G_MS2,boysal=f[7]/G_MS2,hiz=hiz,yaw=f[12],
               kaynak="FORZA_DASH" if len(d)>=331 else "FORZA",
               z_sl=Zemin.ASFALT,z_sr=Zemin.ASFALT,
               z_al=Zemin.ASFALT,z_ar=Zemin.ASFALT)
        if len(d)>=331:
            try:
                ds=struct.unpack_from("<f",d,238)[0]
                if ds>0: k.hiz=ds
            except Exception: pass
        return k
    except Exception: return None

_F1H=  "<HBBBBBQfIBB"
_F1HS= struct.calcsize(_F1H)
_F1C=  "<ffffffhhhhhhffffff"
_F1CS= struct.calcsize(_F1C)

def _f1(d):
    try:
        if len(d)<_F1HS: return None
        h=struct.unpack_from(_F1H,d,0)
        if h[6]!=0: return None
        off=_F1HS+h[9]*_F1CS
        if off+_F1CS>len(d): return None
        c=struct.unpack_from(_F1C,d,off)
        hiz=(c[3]**2+c[4]**2+c[5]**2)**0.5
        return Kare(yanal=c[12],boysal=c[13],hiz=hiz,yaw=c[15],kaynak="F1",
                    z_sl=Zemin.ASFALT,z_sr=Zemin.ASFALT,
                    z_al=Zemin.ASFALT,z_ar=Zemin.ASFALT)
    except Exception: return None

PARSERS:Dict[int,Callable]={
    232:_forza,331:_forza,128:_forza,
    1464:_f1,1347:_f1,1085:_f1,1191:_f1,
    1058:_f1,1015:_f1,970:_f1,1218:_f1,
}

class Alici:
    def __init__(self,port=PORT):
        self._port=port; self._kilit=threading.Lock()
        self._son:Optional[Kare]=None
        self._geri:List[Callable]=[]
        self._dur=threading.Event()
        self._ip:Optional[threading.Thread]=None
        self._sok:Optional[socket.socket]=None
        self._n=self._ok=0
        self._log=logging.getLogger("alici")
    @property
    def son(self):
        with self._kilit: return self._son
    def cb_ekle(self,fn): self._geri.append(fn)
    def baslat(self):
        if self._ip and self._ip.is_alive(): return
        self._dur.clear(); self._n=self._ok=0
        self._ip=threading.Thread(target=self._dongu,daemon=True,name="Alici")
        self._ip.start()
        self._log.info("UDP %d dinleniyor.",self._port)
    def durdur(self):
        self._dur.set()
        try:
            if self._sok: self._sok.close()
        except Exception: pass
        if self._ip: self._ip.join(timeout=2)
    def _dongu(self):
        try:
            s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
            s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
            s.settimeout(0.5); self._sok=s
            s.bind(("0.0.0.0",self._port))
        except OSError as e:
            self._log.error("UDP bind hatasi: %s",e); return
        ilk=True
        while not self._dur.is_set():
            try: d,_=s.recvfrom(4096)
            except socket.timeout: continue
            except OSError: break
            self._n+=1
            p=PARSERS.get(len(d))
            if not p: continue
            k=p(d)
            if not k: continue
            self._ok+=1
            if ilk:
                self._log.info("Telemetri alindi! Kaynak: %s",k.kaynak)
                ilk=False
            with self._kilit: self._son=k
            for fn in list(self._geri):
                try: fn(k)
                except Exception as e: self._log.warning("Callback: %s",e)

# ── FFB Motoru ────────────────────────────────────────────────────────────────
@dataclass
class Yuva:
    eid:int=-1; guc:float=-99.0; per:int=-1; aktif:bool=False
    def kirli(self,g,p=-1,tol=0.015):
        return abs(g-self.guc)>tol or(p!=-1 and p!=self.per)
    def sifirla(self):
        self.eid=-1; self.guc=-99.0; self.per=-1; self.aktif=False

def _u(v): return int(max(0.0,min(1.0,v))*SDLMAX)
def _s(v): return int(max(-1.0,min(1.0,v))*SDLMAX)

class Motor:
    def __init__(self):
        self._k=threading.RLock()
        self._hap=None; self._js=None
        self._haz=False; self._sim=False
        self._yuv={n:Yuva() for n in("yay","son","sin")}
        self._log=logging.getLogger("motor")

    def baslat(self):
        with self._k:
            if not _SDL2:
                self._log.warning("pysdl2 yuklu degil => simulasyon modu.")
                self._sim=True; return False
            if not os.environ.get("PYSDL2_DLL_PATH"):
                if (PROJE/"SDL2.dll").exists():
                    os.environ["PYSDL2_DLL_PATH"]=str(PROJE)
            try:
                if sdl2.SDL_Init(sdl2.SDL_INIT_JOYSTICK|sdl2.SDL_INIT_HAPTIC)<0:
                    self._log.error("SDL_Init: %s",sdl2.SDL_GetError().decode())
                    self._sim=True; return False
            except Exception as e:
                self._log.error("SDL2: %s",e); self._sim=True; return False
            bj=bh=bn=None
            for i in range(sdl2.SDL_NumJoysticks()):
                try:
                    js=sdl2.SDL_JoystickOpen(i)
                    if not js: continue
                    ad=(sdl2.SDL_JoystickName(js) or b"").decode()
                    hap=sdl2.SDL_HapticOpenFromJoystick(js)
                    if not hap: sdl2.SDL_JoystickClose(js); continue
                    if bh is None or "sidewinder" in ad.lower():
                        if bh: sdl2.SDL_HapticClose(bh); sdl2.SDL_JoystickClose(bj)
                        bj,bh,bn=js,hap,ad
                    else: sdl2.SDL_HapticClose(hap); sdl2.SDL_JoystickClose(js)
                except Exception as e: self._log.warning("JS %d: %s",i,e)
            if not bh:
                self._log.warning("Haptic joystick bulunamadi => simulasyon.")
                self._sim=True; return False
            self._js=bj; self._hap=bh; self._haz=True; self._sim=False
            self._log.info("FFB aygiti acildi: '%s'",bn)
            try: sdl2.SDL_HapticRumbleInit(self._hap)
            except Exception: pass
            return True

    def kapat(self):
        with self._k:
            try: self.dur()
            except Exception: pass
            try:
                if self._hap and _SDL2: sdl2.SDL_HapticClose(self._hap)
                if self._js  and _SDL2: sdl2.SDL_JoystickClose(self._js)
                if _SDL2: sdl2.SDL_Quit()
            except Exception as e: self._log.warning("Kapama: %s",e)
            self._hap=self._js=None; self._haz=False

    @property
    def hazir(self): return self._haz or self._sim

    def yay(self,g):
        with self._k:
            y=self._yuv["yay"]
            if not y.kirli(g): return
            if self._sim: y.guc=g; y.aktif=g>0; return
            if not self._haz: return
            try:
                if g<=0: self._yok(y); return
                lv=_u(g); e=sdl2.SDL_HapticEffect(); e.type=sdl2.SDL_HAPTIC_SPRING
                c=e.condition; c.type=sdl2.SDL_HAPTIC_SPRING; c.length=SINF
                for ax in range(2):
                    c.right_sat[ax]=c.left_sat[ax]=lv
                    c.right_coeff[ax]=c.left_coeff[ax]=lv
                    c.deadband[ax]=0; c.center[ax]=0
                y.eid=self._yukle(e,y.eid,SINF); y.guc=g; y.aktif=True
            except Exception as err: self._log.warning("Yay: %s",err)

    def son(self,g):
        with self._k:
            y=self._yuv["son"]
            if not y.kirli(g): return
            if self._sim: y.guc=g; y.aktif=g>0; return
            if not self._haz: return
            try:
                if g<=0: self._yok(y); return
                lv=_u(g); e=sdl2.SDL_HapticEffect(); e.type=sdl2.SDL_HAPTIC_DAMPER
                c=e.condition; c.type=sdl2.SDL_HAPTIC_DAMPER; c.length=SINF
                for ax in range(2):
                    c.right_sat[ax]=c.left_sat[ax]=lv
                    c.right_coeff[ax]=c.left_coeff[ax]=lv
                    c.deadband[ax]=0; c.center[ax]=0
                y.eid=self._yukle(e,y.eid,SINF); y.guc=g; y.aktif=True
            except Exception as err: self._log.warning("Son: %s",err)

    def sin(self,g,per=80):
        with self._k:
            y=self._yuv["sin"]
            if not y.kirli(g,per): return
            if self._sim: y.guc=g; y.per=per; y.aktif=g>0; return
            if not self._haz: return
            try:
                if g<=0: self._yok(y); return
                lv=_u(g); e=sdl2.SDL_HapticEffect(); e.type=sdl2.SDL_HAPTIC_SINE
                p=e.periodic; p.type=sdl2.SDL_HAPTIC_SINE
                p.direction.type=2; p.direction.dir[0]=9000
                p.period=per; p.magnitude=lv; p.offset=p.phase=0; p.length=SINF
                p.attack_length=p.fade_length=80; p.attack_level=p.fade_level=0
                y.eid=self._yukle(e,y.eid,SINF); y.guc=g; y.per=per; y.aktif=True
            except Exception as err: self._log.warning("Sin: %s",err)

    def dur(self):
        with self._k:
            try:
                if self._haz and _SDL2 and self._hap:
                    sdl2.SDL_HapticStopAll(self._hap)
            except Exception: pass
            for y in self._yuv.values(): y.sifirla()

    def dur_sin(self):
        with self._k: self._yok(self._yuv["sin"])
    def dur_yay(self):
        with self._k: self._yok(self._yuv["yay"])

    def _yukle(self,e,eid,rep):
        if not(self._haz and _SDL2 and self._hap): return eid
        try:
            if eid>=0:
                if sdl2.SDL_HapticUpdateEffect(self._hap,eid,e)==0:
                    sdl2.SDL_HapticRunEffect(self._hap,eid,rep); return eid
                sdl2.SDL_HapticDestroyEffect(self._hap,eid)
            nid=sdl2.SDL_HapticNewEffect(self._hap,e)
            if nid<0:
                self._log.error("NewEffect: %s",sdl2.SDL_GetError().decode())
                return -1
            sdl2.SDL_HapticRunEffect(self._hap,nid,rep); return nid
        except Exception as err: self._log.warning("Yukle: %s",err); return eid

    def _yok(self,y):
        try:
            if self._haz and _SDL2 and self._hap and y.eid>=0:
                sdl2.SDL_HapticStopEffect(self._hap,y.eid)
                sdl2.SDL_HapticDestroyEffect(self._hap,y.eid)
        except Exception: pass
        y.sifirla()

# ── Kontrol dongusu ───────────────────────────────────────────────────────────
_SIN_T={Zemin.CIM:(100,0.35),Zemin.TOPRAK:(70,0.45),
        Zemin.CAKIL:(45,0.55),Zemin.KUM:(120,0.30),
        Zemin.BUZ:(200,0.15),Zemin.ARNAVUT:(35,0.60)}

def _efekt(m,k,a):
    try:
        sp=_SIN_T.get(k.zemin)
        if sp: m.sin(sp[1],sp[0])
        else: m.dur_sin()
        lat=k.abs_yanal
        if lat>=0.15:
            t=min((lat-0.15)/max(a.g_max-0.15,0.1),1.0)
            ys=a.yay_min+t*(a.yay_max-a.yay_min)
        else: ys=0.0
        m.yay(ys)
        gc=min(lat/max(a.g_max,0.1),1.0)*a.son_g
        hc=0.0 if k.kir else min(k.hiz/a.hiz_ref,1.0)*a.son_hiz
        m.son(min(a.son_taban+gc+hc,1.0))
    except Exception as e:
        logging.getLogger("efekt").warning("Efekt: %s",e)

def kontrol(m,al,dur,a):
    aralik=1.0/HZ; son_g=0.0; timeout=False
    lg=logging.getLogger("kontrol")
    lg.info("Kontrol dongusu basladi (%d Hz)",HZ)
    while not dur.is_set():
        t0=time.monotonic()
        k=al.son
        if k and(t0-k.t)<a.zaman_asimi:
            if timeout or not son_g: timeout=False
            son_g=t0; _efekt(m,k,a)
        elif son_g and(t0-son_g)>a.zaman_asimi:
            if not timeout:
                timeout=True
                lg.info("Telemetri zaman asimi.")
                try: m.dur_sin(); m.dur_yay(); m.son(a.son_taban)
                except Exception: pass
        dt=time.monotonic()-t0
        r=aralik-dt
        if r>0: time.sleep(r)

# ════════════════════════════════════════════════════════════════════════════
# AYARLAR PENCERESİ (tkinter)
# ════════════════════════════════════════════════════════════════════════════
class AyarlarPenceresi:
    """
    Bagimsiz ayarlar penceresi.
    motor ve alici referanslari ile canli bilgi gosterir.
    """
    def __init__(self, ayar:Ayar, motor:Motor, alici:Alici,
                 uygulama_ref, tray_ref=None):
        if not _TK:
            LOG.error("tkinter yuklu degil!")
            return
        self.ayar=ayar; self.m=motor; self.al=alici
        self.app=uygulama_ref; self.tray=tray_ref
        self._pencere:Optional[tk.Tk]=None
        self._canli_thread:Optional[threading.Thread]=None
        self._dur=threading.Event()

    def ac(self):
        """Pencereyi arka plan threadinde ac (tray callback'ten cagrilir)."""
        threading.Thread(target=self._olustur, daemon=True, name="GUI").start()

    def _olustur(self):
        if self._pencere and self._pencere.winfo_exists():
            # Zaten aciksa one getir
            try: self._pencere.lift(); self._pencere.focus_force()
            except Exception: pass
            return

        pen = tk.Tk()
        pen.title(f"{AD}  v{SURUM}  —  Ayarlar")
        pen.geometry("620x680")
        pen.resizable(False, False)
        pen.configure(bg="#1a1a2e")
        self._pencere = pen

        # Kapatinca sadece gizle
        pen.protocol("WM_DELETE_WINDOW", self._gizle)

        self._icerik_olustur(pen)

        # Canli guncelleme
        self._dur.clear()
        self._canli_guncelle()

        pen.mainloop()

    def _gizle(self):
        try:
            self._dur.set()
            if self._pencere:
                self._pencere.destroy()
                self._pencere = None
        except Exception: pass

    def _icerik_olustur(self, pen:tk.Tk):
        KOYU  = "#1a1a2e"
        PANEL = "#16213e"
        KART  = "#0f3460"
        YESIL = "#4ade80"
        MAVI  = "#60a5fa"
        SARI  = "#fbbf24"
        KIRMIZI="#f87171"
        BYZ   = "#e2e8f0"
        GRI   = "#64748b"

        stil = ttk.Style()
        stil.theme_use("clam")
        stil.configure("TNotebook",      background=KOYU, borderwidth=0)
        stil.configure("TNotebook.Tab",  background=PANEL, foreground=BYZ,
                       padding=[12,5], font=("Segoe UI",10,"bold"))
        stil.map("TNotebook.Tab",        background=[("selected",KART)])
        stil.configure("TFrame",         background=KOYU)
        stil.configure("dark.TFrame",    background=PANEL)
        stil.configure("card.TFrame",    background=KART)
        stil.configure("TScale",         background=KOYU, troughcolor=PANEL)
        stil.configure("TLabel",         background=KOYU, foreground=BYZ,
                       font=("Segoe UI",9))
        stil.configure("head.TLabel",    background=KOYU, foreground=MAVI,
                       font=("Segoe UI",11,"bold"))
        stil.configure("val.TLabel",     background=KOYU, foreground=YESIL,
                       font=("Consolas",10,"bold"))
        stil.configure("TButton",        background=KART, foreground=BYZ,
                       font=("Segoe UI",9,"bold"), padding=[8,4])
        stil.map("TButton", background=[("active","#1e4080")])

        # ── Baslik ───────────────────────────────────────────────────
        baslik = tk.Frame(pen, bg=KART, height=50)
        baslik.pack(fill="x")
        tk.Label(baslik, text=f"  {AD}  v{SURUM}",
                 bg=KART, fg=MAVI,
                 font=("Segoe UI",14,"bold")).pack(side="left", pady=8, padx=8)

        # Durum badge (calisma + cihaz)
        self._durum_lbl = tk.Label(baslik, text="● Baslatilayor...",
                                   bg=KART, fg=SARI,
                                   font=("Segoe UI",9,"bold"))
        self._durum_lbl.pack(side="right", padx=12)

        # ── Sekmeler ──────────────────────────────────────────────────
        nb = ttk.Notebook(pen)
        nb.pack(fill="both", expand=True, padx=8, pady=6)

        # Sekme 1: Canli Durum
        f_durum = ttk.Frame(nb)
        nb.add(f_durum, text="  Canli Durum  ")
        self._durum_sekmesi(f_durum, KOYU, PANEL, KART,
                            YESIL, MAVI, SARI, KIRMIZI, BYZ, GRI)

        # Sekme 2: FFB Ayarlari
        f_ayar = ttk.Frame(nb)
        nb.add(f_ayar, text="  FFB Ayarlari  ")
        self._ayar_sekmesi(f_ayar, KOYU, PANEL, KART, YESIL, MAVI, BYZ, SARI)

        # Sekme 3: Hakkinda
        f_hk = ttk.Frame(nb)
        nb.add(f_hk, text="  Hakkinda  ")
        self._hakkinda_sekmesi(f_hk, KOYU, PANEL, MAVI, BYZ, GRI)

        # ── Alt butonlar ───────────────────────────────────────────────
        alt = tk.Frame(pen, bg=PANEL, height=44)
        alt.pack(fill="x", side="bottom")

        def kapat(): self.app._durdur() if self.app._cal else None; self._gizle()
        def log_ac():
            import subprocess
            subprocess.Popen(["explorer", str(APPDIR)])

        ttk.Button(alt, text="Gizle",       command=self._gizle).pack(
            side="right", padx=6, pady=6)
        ttk.Button(alt, text="Log Klasoru", command=log_ac).pack(
            side="right", padx=2, pady=6)
        ttk.Button(alt, text="Cikis",
                   command=lambda: self.app._cikis()).pack(
            side="left", padx=6, pady=6)

    # ── Sekme 1: Canli Durum ──────────────────────────────────────────────────
    def _durum_sekmesi(self, f, KOYU, PANEL, KART,
                       YESIL, MAVI, SARI, KIRMIZI, BYZ, GRI):
        f.configure(style="TFrame")

        def kart(parent, baslik_t, renk):
            c = tk.LabelFrame(parent, text=f"  {baslik_t}  ",
                              bg=PANEL, fg=renk,
                              font=("Segoe UI",9,"bold"),
                              bd=1, relief="solid")
            return c

        # Satir 1: Telemetri + FFB yan yana
        ust = tk.Frame(f, bg=KOYU)
        ust.pack(fill="x", padx=10, pady=(10,4))

        tele_kart = kart(ust, "Telemetri", MAVI)
        tele_kart.pack(side="left", fill="both", expand=True, padx=(0,4))

        ffb_kart = kart(ust, "FFB Durum", YESIL)
        ffb_kart.pack(side="left", fill="both", expand=True)

        # Telemetri icerigi
        tele_items = [
            ("Yanal G-Kuvveti",  "t_yanal"),
            ("Boysal G-Kuvveti", "t_boysal"),
            ("Hiz (km/h)",       "t_hiz"),
            ("Zemin Tipi",       "t_zemin"),
            ("Kaynak",           "t_kaynak"),
        ]
        self._tele_lbls = {}
        for i,(lbl_t,key) in enumerate(tele_items):
            tk.Label(tele_kart, text=lbl_t+":", bg=PANEL, fg=GRI,
                     font=("Segoe UI",8), anchor="w",
                     width=18).grid(row=i, column=0, sticky="w", padx=6, pady=2)
            v = tk.Label(tele_kart, text="---",
                         bg=PANEL, fg=BYZ,
                         font=("Consolas",9,"bold"), anchor="w", width=14)
            v.grid(row=i, column=1, sticky="w", padx=4, pady=2)
            self._tele_lbls[key] = v

        # FFB icerigi
        ffb_items = [
            ("Cihaz",      "f_cihaz"),
            ("Yay Gucu",   "f_yay"),
            ("Sonumleme",  "f_son"),
            ("Sinüs",      "f_sin"),
            ("Mod",        "f_mod"),
        ]
        self._ffb_lbls = {}
        for i,(lbl_t,key) in enumerate(ffb_items):
            tk.Label(ffb_kart, text=lbl_t+":", bg=PANEL, fg=GRI,
                     font=("Segoe UI",8), anchor="w",
                     width=12).grid(row=i, column=0, sticky="w", padx=6, pady=2)
            v = tk.Label(ffb_kart, text="---",
                         bg=PANEL, fg=BYZ,
                         font=("Consolas",9,"bold"), anchor="w", width=16)
            v.grid(row=i, column=1, sticky="w", padx=4, pady=2)
            self._ffb_lbls[key] = v

        # G-kuvveti bar
        g_kart = kart(f, "Yanal G-Kuvveti Gosterge", SARI)
        g_kart.pack(fill="x", padx=10, pady=4)

        self._g_canvas = tk.Canvas(g_kart, height=30, bg="#0a0a1a", bd=0,
                                   highlightthickness=0)
        self._g_canvas.pack(fill="x", padx=6, pady=6)

        # Log son satirlari
        log_kart = kart(f, "Son Log Satirlari", GRI)
        log_kart.pack(fill="both", expand=True, padx=10, pady=(4,6))

        self._log_text = tk.Text(log_kart, height=7, bg="#0d0d1a", fg=GRI,
                                  font=("Consolas",8), state="disabled",
                                  relief="flat", bd=0)
        self._log_text.pack(fill="both", expand=True, padx=4, pady=4)
        sb = tk.Scrollbar(log_kart, command=self._log_text.yview)
        self._log_text.configure(yscrollcommand=sb.set)

    # ── Sekme 2: FFB Ayarlari ─────────────────────────────────────────────────
    def _ayar_sekmesi(self, f, KOYU, PANEL, KART, YESIL, MAVI, BYZ, SARI):
        f.configure(style="TFrame")

        canvas = tk.Canvas(f, bg=KOYU, bd=0, highlightthickness=0)
        scroll = tk.Scrollbar(f, orient="vertical", command=canvas.yview)
        ic = tk.Frame(canvas, bg=KOYU)

        ic.bind("<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0,0), window=ic, anchor="nw")
        canvas.configure(yscrollcommand=scroll.set)

        canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

        # Slider parametreleri: (label, attr, min, max, format)
        sliders = [
            ("Maksimum G-Kuvveti (G)",   "g_max",     0.5, 6.0,   "{:.1f} G"),
            ("Minimum Yay Gucu",          "yay_min",   0.0, 1.0,   "{:.0%}"),
            ("Maksimum Yay Gucu",         "yay_max",   0.0, 1.0,   "{:.0%}"),
            ("Taban Sonumleme",           "son_taban", 0.0, 1.0,   "{:.0%}"),
            ("G-Bazli Sonumleme Olcegi",  "son_g",     0.0, 1.0,   "{:.0%}"),
            ("Hiz-Bazli Sonumleme",       "son_hiz",   0.0, 1.0,   "{:.0%}"),
            ("Referans Hiz (m/s)",        "hiz_ref",   10.0,200.0, "{:.0f} m/s"),
            ("Telemetri Zaman Asimi (s)", "zaman_asimi",0.5,10.0,  "{:.1f} s"),
        ]

        tk.Label(ic, text="FFB Kuvvet Parametreleri",
                 bg=KOYU, fg=MAVI,
                 font=("Segoe UI",11,"bold")).pack(pady=(12,4), padx=12, anchor="w")

        tk.Label(ic, text="Kaydiriciyi suruklleyin, Kaydet'e basin.",
                 bg=KOYU, fg="#64748b",
                 font=("Segoe UI",8)).pack(padx=12, anchor="w")

        self._slider_vars = {}
        for lbl_t, attr, mn, mx, fmt in sliders:
            satir = tk.Frame(ic, bg=PANEL, relief="flat", bd=1)
            satir.pack(fill="x", padx=12, pady=3)

            ust_s = tk.Frame(satir, bg=PANEL)
            ust_s.pack(fill="x", padx=8, pady=(6,0))

            tk.Label(ust_s, text=lbl_t, bg=PANEL, fg=BYZ,
                     font=("Segoe UI",9)).pack(side="left")

            val_lbl = tk.Label(ust_s, text=fmt.format(getattr(self.ayar,attr)),
                               bg=PANEL, fg=YESIL,
                               font=("Consolas",9,"bold"), width=10)
            val_lbl.pack(side="right")

            var = tk.DoubleVar(value=getattr(self.ayar, attr))

            def yap_cb(v, a=attr, vl=val_lbl, f=fmt):
                vl.config(text=f.format(float(v)))
                setattr(self.ayar, a, float(v))

            sl = ttk.Scale(satir, from_=mn, to=mx, orient="horizontal",
                           variable=var, command=yap_cb)
            sl.pack(fill="x", padx=8, pady=(2,6))
            self._slider_vars[attr] = var

        # Port ayari
        port_satir = tk.Frame(ic, bg=PANEL)
        port_satir.pack(fill="x", padx=12, pady=3)
        tk.Label(port_satir, text="UDP Port:", bg=PANEL, fg=BYZ,
                 font=("Segoe UI",9)).pack(side="left", padx=8, pady=8)
        self._port_var = tk.StringVar(value=str(self.ayar.udp_port))
        tk.Entry(port_satir, textvariable=self._port_var, width=8,
                 bg=KART, fg=BYZ, font=("Consolas",10),
                 insertbackground=BYZ, relief="flat").pack(side="left", padx=4)

        # Kaydet butonu
        def kaydet():
            try:
                self.ayar.udp_port = int(self._port_var.get())
            except ValueError: pass
            self.ayar.kaydet()
            # Ekranda bildir
            kaydet_lbl.config(text="Kaydedildi!", fg=YESIL)
            if self._pencere:
                self._pencere.after(2000,
                    lambda: kaydet_lbl.config(text="", fg=KOYU))
            LOG.info("Ayarlar kaydedildi.")

        alt_ayar = tk.Frame(ic, bg=KOYU)
        alt_ayar.pack(fill="x", padx=12, pady=8)

        ttk.Button(alt_ayar, text="  Kaydet  ", command=kaydet).pack(
            side="left")
        kaydet_lbl = tk.Label(alt_ayar, text="", bg=KOYU, fg=YESIL,
                              font=("Segoe UI",9,"bold"))
        kaydet_lbl.pack(side="left", padx=8)

        def sifirla():
            yeni = Ayar()
            for attr, var in self._slider_vars.items():
                var.set(getattr(yeni, attr))
                setattr(self.ayar, attr, getattr(yeni, attr))
            LOG.info("Ayarlar sifirlandı.")

        ttk.Button(alt_ayar, text="Sifirla",command=sifirla).pack(
            side="right")

    # ── Sekme 3: Hakkinda ─────────────────────────────────────────────────────
    def _hakkinda_sekmesi(self, f, KOYU, PANEL, MAVI, BYZ, GRI):
        f.configure(style="TFrame")
        ic = tk.Frame(f, bg=KOYU)
        ic.pack(expand=True)

        tk.Label(ic, text=AD, bg=KOYU, fg=MAVI,
                 font=("Segoe UI",20,"bold")).pack(pady=(30,4))
        tk.Label(ic, text=f"Surum {SURUM}", bg=KOYU, fg=GRI,
                 font=("Segoe UI",10)).pack()
        tk.Label(ic, text="DIY / Arduino Direksiyon FFB Sarmalayici",
                 bg=KOYU, fg=BYZ,
                 font=("Segoe UI",10)).pack(pady=(8,0))

        tk.Frame(ic, bg=PANEL, height=1, width=400).pack(pady=16)

        bilgi = [
            (f"Python", sys.version.split()[0]),
            ("Log Dosyasi", str(LOGDOS)),
            ("Ayar Dosyasi", str(AYARDOS)),
            ("pysdl2", "Kurulu" if _SDL2 else "EKSIK"),
            ("pystray", "Kurulu" if _TRAY else "EKSIK"),
            ("tkinter", "Kurulu" if _TK else "EKSIK"),
        ]
        for lbl,val in bilgi:
            satir = tk.Frame(ic, bg=KOYU)
            satir.pack(fill="x", padx=40, pady=1)
            tk.Label(satir, text=lbl+":", bg=KOYU, fg=GRI,
                     font=("Segoe UI",9), width=14,
                     anchor="e").pack(side="left")
            tk.Label(satir, text=val, bg=KOYU, fg=BYZ,
                     font=("Consolas",9)).pack(side="left", padx=8)

        tk.Frame(ic, bg=PANEL, height=1, width=400).pack(pady=12)
        tk.Label(ic, text="Desteklenen Oyunlar: Forza, F1 Serisi (UDP 20777)",
                 bg=KOYU, fg=GRI,
                 font=("Segoe UI",8)).pack()

    # ── Canli guncelleme döngüsü ──────────────────────────────────────────────
    def _canli_guncelle(self):
        if self._dur.is_set(): return
        if not self._pencere: return

        try:
            # Telemetri verileri
            k = self.al.son
            if k:
                yg  = k.yanal
                bsg = k.boysal
                hiz = k.hiz_kmh
                zm  = k.zemin.name
                kr  = k.kaynak
                yas = f"{yg:+.3f} G"
                bas = f"{bsg:+.3f} G"
                hzs = f"{hiz:.1f}"
            else:
                yas=bas=hzs=zm=kr = "---"

            if hasattr(self,"_tele_lbls"):
                t = self._tele_lbls
                t["t_yanal"].config(text=yas)
                t["t_boysal"].config(text=bas)
                t["t_hiz"].config(text=hzs)
                t["t_zemin"].config(text=zm)
                t["t_kaynak"].config(text=kr)

            # FFB durumu
            if hasattr(self,"_ffb_lbls"):
                f = self._ffb_lbls
                cihaz = "Gercek" if self.m._haz else ("Sim" if self.m._sim else "Kapali")
                yay_v = self.m._yuv["yay"].guc
                son_v = self.m._yuv["son"].guc
                sin_v = self.m._yuv["sin"].guc
                mod   = "Aktif" if self.app._cal else "Durduruldu"

                f["f_cihaz"].config(
                    text="SideWinder" if self.m._haz else cihaz,
                    fg="#4ade80" if self.m._haz else "#fbbf24")
                f["f_yay"].config(
                    text=f"{yay_v:.2f}" if yay_v>-98 else "---")
                f["f_son"].config(
                    text=f"{son_v:.2f}" if son_v>-98 else "---")
                f["f_sin"].config(
                    text=f"{sin_v:.2f}" if sin_v>-98 else "---")
                f["f_mod"].config(
                    text=mod,
                    fg="#4ade80" if self.app._cal else "#f87171")

            # G-bar guncelle
            if hasattr(self,"_g_canvas"):
                self._g_bar_ciz(k.yanal if k else 0.0)

            # Durum badge
            if hasattr(self,"_durum_lbl"):
                if not self.app._cal:
                    self._durum_lbl.config(text="■ Durduruldu", fg="#f87171")
                elif not k:
                    self._durum_lbl.config(text="⏳ Oyun Bekleniyor...", fg="#fbbf24")
                else:
                    self._durum_lbl.config(text="● FFB Aktif", fg="#4ade80")

            # Log satirlari
            if hasattr(self,"_log_text"):
                try:
                    loglar = LOGDOS.read_text(encoding="utf-8",
                                              errors="replace").split("\n")
                    son10  = "\n".join(loglar[-10:])
                    self._log_text.config(state="normal")
                    self._log_text.delete("1.0","end")
                    self._log_text.insert("end", son10)
                    self._log_text.config(state="disabled")
                    self._log_text.see("end")
                except Exception: pass

        except Exception as e:
            LOG.debug("GUI guncelleme: %s", e)

        # 500ms'de bir tekrar
        if self._pencere and not self._dur.is_set():
            try: self._pencere.after(500, self._canli_guncelle)
            except Exception: pass

    def _g_bar_ciz(self, g:float):
        try:
            cv = self._g_canvas
            cv.delete("all")
            w = cv.winfo_width()
            if w < 10: w = 580
            h = 30
            cx = w // 2

            # Merkez cizgi
            cv.create_line(cx, 2, cx, h-2, fill="#334155", width=1)

            # Arka plan
            cv.create_rectangle(2, 6, w-2, h-6, fill="#0a0a1a",
                                 outline="#1e293b")

            # G bar
            g_norm = max(-1.0, min(1.0, g / max(self.ayar.g_max, 0.1)))
            bar_w  = int(abs(g_norm) * (w//2 - 6))

            if g_norm >= 0:
                x1, x2 = cx, cx + bar_w
                renk = "#ef4444" if abs(g) > self.ayar.g_max*0.8 else "#22c55e"
            else:
                x1, x2 = cx - bar_w, cx
                renk = "#ef4444" if abs(g) > self.ayar.g_max*0.8 else "#3b82f6"

            if bar_w > 0:
                cv.create_rectangle(x1, 8, x2, h-8, fill=renk, outline="")

            # G degeri yazi
            cv.create_text(cx, h//2, text=f"{g:+.2f} G",
                           fill="white", font=("Consolas",9,"bold"))
        except Exception: pass


# ════════════════════════════════════════════════════════════════════════════
# TRAY + ANA UYGULAMA
# ════════════════════════════════════════════════════════════════════════════
class Durum(IntEnum):
    KAPALI=0; BAGLAN=1; BEKLE=2; AKTIF=3

def _simge_ciz(d:Durum):
    renkler={Durum.KAPALI:(130,130,130),Durum.BAGLAN:(240,200,40),
             Durum.BEKLE:(60,140,240),  Durum.AKTIF:(50,220,90)}
    c=renkler.get(d,(130,130,130))
    S=256; im=Image.new("RGBA",(S,S),(0,0,0,0)); dr=ImageDraw.Draw(im)
    p=max(int(S*0.07),2); kl=max(int(S*0.09),1)
    dr.ellipse([p,p,S-p,S-p],outline=c,width=kl)
    hr=S*0.14; cx=cy=S//2
    dr.ellipse([cx-hr,cy-hr,cx+hr,cy+hr],fill=c)
    r=S//2-p-kl//2
    for ag in[90,210,330]:
        rad=math.radians(ag)
        ex=cx+r*math.cos(rad); ey=cy-r*math.sin(rad)
        dr.line([cx,cy,ex,ey],fill=c,width=max(kl-1,1))
    return im.resize((64,64),Image.LANCZOS)

class Uygulama:
    def __init__(self,a:Ayar):
        self.a=a
        self.m=Motor()
        self.al=Alici(port=a.udp_port)
        self._d=Durum.KAPALI
        self._cal=False
        self._dur=threading.Event()
        self._ip:Optional[threading.Thread]=None
        self._ico:Optional[pystray.Icon]=None
        self._log=logging.getLogger("uygulama")
        self._gui:Optional[AyarlarPenceresi]=None

    def calistir(self):
        # GUI nesnesi hazirla
        if _TK:
            self._gui = AyarlarPenceresi(self.a, self.m, self.al, self)

        if not _TRAY:
            self._log.error("pystray yuklu degil - konsol modu")
            self._konsol(); return

        try:
            ikon_dos = PROJE / "icon.ico"
            if ikon_dos.exists() and _TRAY:
                ikon = Image.open(ikon_dos).convert("RGBA")
                ikon = ikon.resize((64,64),Image.LANCZOS)
            else:
                ikon = _simge_ciz(Durum.KAPALI)

            self._ico = pystray.Icon(
                AD, icon=ikon, title=f"{AD} v{SURUM}",
                menu=self._menu_olustur())
            threading.Timer(0.8, self._baslat).start()
            self._log.info("Sistem tepsisi baslatiliyor...")
            self._ico.run()
        except Exception as e:
            self._log.error("Tepsi: %s", e)
            self._konsol()

    def _menu_olustur(self):
        d_metin = {
            Durum.KAPALI:"Kapali",
            Durum.BAGLAN:"Baglaniyor...",
            Durum.BEKLE: "Oyun Bekleniyor (UDP 20777)...",
            Durum.AKTIF: "FFB Aktif - SideWinder Bagli",
        }
        return pystray.Menu(
            pystray.MenuItem(
                lambda _: d_metin.get(self._d,"?"),
                None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Ayarlar Penceresi", self._ayarlar_ac, default=True),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem(
                lambda _: "Durdur" if self._cal else "Baslat",
                self._togel),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Cikis", lambda *_: self._cikis()),
        )

    def _ayarlar_ac(self, *_):
        if self._gui:
            self._gui.ac()
        else:
            self._log.warning("tkinter yuklu degil - GUI acilamiyor")

    def _togel(self, *_):
        if self._cal: self._durdur()
        else: self._baslat()
        self._guncelle()

    def _cikis(self):
        self._durdur()
        if self._ico: self._ico.stop()

    def _konsol(self):
        print(f"\n  {AD} v{SURUM}  |  Cikis: Ctrl+C\n")
        self._baslat()
        try:
            while True:
                time.sleep(1)
                k=self.al.son
                if k:
                    print(f"\r  [{k.kaynak}] YG={k.yanal:+.2f}G  "
                          f"{k.hiz_kmh:.0f}km/h  {k.zemin.name}    ",
                          end="",flush=True)
        except KeyboardInterrupt: print()
        finally: self._durdur()

    def _set_d(self,d:Durum):
        self._d=d; self._guncelle()

    def _guncelle(self):
        if self._ico:
            try:
                self._ico.icon=_simge_ciz(self._d)
                self._ico.title=f"{AD} - {self._d.name}"
                self._ico.update_menu()
            except Exception: pass

    def _baslat(self):
        if self._cal: return
        self._log.info("Baslıyor...")
        self._set_d(Durum.BAGLAN)
        try:
            ok=self.m.baslat()
            if not ok: self._log.warning("FFB aygiti yok - simulasyon modu.")
        except Exception as e: self._log.error("Motor: %s",e)
        try: self.al.baslat()
        except Exception as e: self._log.error("Alici: %s",e)
        def _ilk(_): self._set_d(Durum.AKTIF)
        self.al.cb_ekle(_ilk)
        self._dur.clear()
        self._ip=threading.Thread(
            target=kontrol,args=(self.m,self.al,self._dur,self.a),
            daemon=True,name="Kontrol")
        self._ip.start()
        self._cal=True
        self._set_d(Durum.BEKLE)
        self._log.info("Hazir. UDP %d dinleniyor...",self.a.udp_port)

    def _durdur(self):
        if not self._cal: return
        self._log.info("Duruyor...")
        self._set_d(Durum.KAPALI)
        self._dur.set()
        if self._ip: self._ip.join(timeout=3)
        try: self.al.durdur()
        except Exception: pass
        try: self.m.dur(); self.m.kapat()
        except Exception: pass
        self.m=Motor(); self.al=Alici(port=self.a.udp_port)
        self._cal=False

# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    LOG.info("="*60)
    LOG.info("  %s v%s",AD,SURUM)
    LOG.info("  Python: %s",sys.version.split()[0])
    LOG.info("  pysdl2:%s pystray:%s tkinter:%s",_SDL2,_TRAY,_TK)
    LOG.info("="*60)
    a=Ayar.yukle()
    u=Uygulama(a)
    try: u.calistir()
    except KeyboardInterrupt: LOG.info("Ctrl+C")
    except Exception as e: LOG.error("Hata: %s",e,exc_info=True)
    finally:
        try: u._durdur()
        except Exception: pass
        LOG.info("Kapatildi.")

if __name__=="__main__":
    main()

@echo off
title SideWinder FFB

set "KOK=%~dp0"
if "%KOK:~-1%"=="\" set "KOK=%KOK:~0,-1%"
cd /d "%KOK%"

:: GUI icin customtkinter gerekli - yuklu mu kontrol et
py -3.12 --version >nul 2>&1
if %errorlevel% neq 0 (
    echo Python 3.12 bulunamadi!
    echo https://www.python.org/downloads/release/python-3128/
    pause & exit /b 1
)

py -3.12 -c "import customtkinter" >nul 2>&1
if %errorlevel% neq 0 (
    echo customtkinter yukleniyor...
    py -3.12 -m pip install customtkinter --prefer-binary
)

py -3.12 -c "import pystray, PIL, sdl2" >nul 2>&1
if %errorlevel% neq 0 (
    echo Temel paketler yukleniyor...
    py -3.12 -m pip install pysdl2 pysdl2-dll pystray Pillow --prefer-binary
)

py -3.12 -c "import vgamepad" >nul 2>&1
if %errorlevel% neq 0 (
    echo vgamepad yukleniyor (ViGEmBus surucusu gerektirir)...
    py -3.12 -m pip install vgamepad --prefer-binary
)
if %errorlevel% neq 0 (
    echo Temel paketler yukleniyor...
    py -3.12 -m pip install pysdl2 pysdl2-dll pystray Pillow --prefer-binary
)

py -3.12 "%KOK%\gui_app.py"

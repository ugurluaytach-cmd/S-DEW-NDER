# Hakkinda / About

Merhaba, ben **Aytac**.

Ikinci el bir Microsoft SideWinder Force Feedback 2 aldim.
Meğer eski bir direksiyon setiymiş, Microsoft destegi kesilmis, bilmiyordum.

Cozumu beklemek yerine AI araclari kullanarak kendim yazdim.
Acik kaynak koda inandığım icin bu projeyi siz degerli yazilimcilara,
acik sistemi savunan insanlara emanet ediyorum.

Belki ileride kendim icin modifikasyonlar yaparim.
Ama simdiden: **fork edin, gelistirin, iyi eglenin.**

Tesekkurler.

*— Aytac*

---

> Projeyi faydali bulursan bir star birak — en buyuk motivasyon o!

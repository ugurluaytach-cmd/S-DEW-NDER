# SideWinder FFB — Universal Force Feedback Wrapper

> *Eski bir direksiyon, modern oyunlar, sıfır resmi destek. Çözümü kendim yazdım.*
> — Aytac

![Python](https://img.shields.io/badge/Python-3.12-blue)
![Platform](https://img.shields.io/badge/Platform-Windows-lightgrey)
![License](https://img.shields.io/badge/License-MIT-green)

---

## Hikaye

Ikinci el bir **Microsoft SideWinder Force Feedback 2** aldim.
Harika bir direksiyon seti — ama Microsoft destegi yillar once kesilmis,
modern oyunlar tanimiyor, Force Feedback motorlari olu yatiyor.

Cozumu beklemek yerine AI araclari da kullanarak kendim yazdim.
Eksikler olabilir ama temeli saglam. Birkaç modifikasyonla
**tum noname direksiyonlara** uyarlanabilir.

Artik bu projeyi size birakiyorum.
Acik kaynak kodun gucune inanan, elinde eski ama iyi bir donanim olan,
"bunu neden kimse yapmamis?" diye soran herkese:
**Fork edin, gelistirin, paylasin.**

*— Aytac*

---

## Ozellikler

- **Canli Force Feedback** — Forza / F1 telemetri verisiyle yay, sonumleme, titresim efektleri
- **Hybrid Gamepad Modu** — ViGEmBus ile Xbox 360 kolu taklidi, oyun ayari gerekmez
- **Kalibrasyon** — Merkez, sol/sag limit ogretme, deadzone ve hassasiyet
- **Canli Giris Gosterge** — Buton flash, direksiyon bari, pedal barlari, analog crosshair
- **Sistem Tepsisi** — Arka planda calisir, Windows ile baslar
- **Tek tik derleme** — `build_exe.bat` ile bagimsiz `.exe`

---

## Hizli Baslangic

```
1. Calistir.bat dosyasina cift tiklayin
   (ilk calistirmada paketler otomatik yuklenır)

2. Sistem tepsisinde direksiyon simgesi belirir
   Cift tiklayin — ayarlar penceresi acilir

3. Forza / F1 icin: UDP telemetri port 20777 aktif edin
```

---

## Gereksinimler

| Gereksinim | Not |
|---|---|
| Windows 10/11 64-bit | |
| Python 3.12 | [python.org](https://python.org) — kurulumda "Add to PATH" isaretleyin |
| ViGEmBus surucusu | Sadece Gamepad Emulasyon modu icin — [indir](https://github.com/nefarius/ViGEmBus/releases) |
| SideWinder FF2 | SDL2 uyumlu her haptic joystick de calisir |

---

## EXE Derleme

```bat
build_exe.bat
```

Cikti: `dist\SideWinderFFB.exe` — hedef makinede Python gerekmez.

---

## Proje Yapisi

```
sidewinder_ffb.py   FFB motoru + telemetri (GUI bagimsiz)
gui_app.py          CustomTkinter arayuz
icon.py             Derleme sirasinda icon.ico uretir
Calistir.bat        Tek tik baslatic / otomatik yukleyici
build_exe.bat       PyInstaller derleme scripti
make_spec.py        DLL yollarini dogru ayarli .spec uretici
requirements.txt    Python bagimliliklar
```

---

## Desteklenen Oyunlar

| Oyun | Ayar |
|---|---|
| Forza Motorsport / Horizon | HUD & Gameplay → Data Out → ON, Port 20777 |
| F1 23 / F1 24 | Settings → Telemetry → UDP ON, Port 20777 |

---

## Lisans

MIT — dilediginiz gibi kullanin, gelistirin, paylasin.

@echo off
title SideWinder FFB - EXE Build

set "KOK=%~dp0"
if "%KOK:~-1%"=="\" set "KOK=%KOK:~0,-1%"
cd /d "%KOK%"

echo.
echo  ============================================================
echo   SideWinder FFB  v4  -  EXE Build
echo  ============================================================
echo.

:: Gerekli paketler
py -3.12 -c "import PyInstaller" >nul 2>&1
if %errorlevel% neq 0 (
    echo [..] PyInstaller kuruluyor...
    py -3.12 -m pip install pyinstaller --prefer-binary
)

:: Eski build temizle
if exist "%KOK%\build" rmdir /s /q "%KOK%\build" >nul 2>&1
if exist "%KOK%\dist"  rmdir /s /q "%KOK%\dist"  >nul 2>&1
echo [OK] Eski dosyalar temizlendi

:: ?????? SDL2.dll bul ???????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????????
echo [..] SDL2.dll araniyor...
set "SDL2_PATH="

:: Yontem 1: Python prefix agacini tara
for /f "delims=" %%F in ('py -3.12 -c "import pathlib,sys; r=sorted(pathlib.Path(sys.prefix).rglob(\"SDL2.dll\")); print(str(r[0]) if r else \"NONE\")" 2^>nul') do set "SDL2_PATH=%%F"
if "%SDL2_PATH%"=="NONE" set "SDL2_PATH="

:: Yontem 2: pysdl2_dll paketine sor
if not defined SDL2_PATH (
    for /f "delims=" %%F in ('py -3.12 -c "import pathlib; import pysdl2_dll; b=pathlib.Path(pysdl2_dll.__file__).parent; r=list(b.rglob(\"SDL2.dll\")); print(str(r[0]) if r else \"NONE\")" 2^>nul') do set "SDL2_PATH=%%F"
)
if "%SDL2_PATH%"=="NONE" set "SDL2_PATH="

:: Yontem 3: Proje klasorunun kendisi
if not defined SDL2_PATH (
    if exist "%KOK%\SDL2.dll" set "SDL2_PATH=%KOK%\SDL2.dll"
)

if not defined SDL2_PATH (
    echo.
    echo [HATA] SDL2.dll bulunamadi!
    echo Cozum: Kur-Baslat.bat calistirin, SDL2.dll otomatik kurulur.
    echo.
    pause & exit /b 1
)
echo [OK] SDL2.dll: %SDL2_PATH%

:: SDL2.dll'yi proje klasorune kopyala (spec icin zorunlu)
if not "%SDL2_PATH%"=="%KOK%\SDL2.dll" (
    copy /y "%SDL2_PATH%" "%KOK%\SDL2.dll" >nul
    echo [OK] SDL2.dll proje klasorune kopyalandi
)

:: spec dosyasini olustur ve PyInstaller'i calistir
echo.
echo [..] SideWinderFFB.spec olusturuluyor...

py -3.12 "%KOK%\make_spec.py" "%KOK%"
if %errorlevel% neq 0 (
    echo [HATA] make_spec.py basarisiz!
    pause & exit /b 1
)

echo [..] Derleniyor... (3-6 dakika)
echo.

py -3.12 -m PyInstaller --clean --noconfirm "%KOK%\SideWinderFFB.spec"

if %errorlevel% equ 0 (
    echo.
    echo [OK] BASARILI: dist\SideWinderFFB.exe
    explorer "%KOK%\dist"
) else (
    echo.
    echo [HATA] Derleme basarisiz.
    echo Antivirusu gecici kapat ve tekrar dene.
    echo Log: build\SideWinderFFB\warn-SideWinderFFB.txt
)
echo.
pause

"""
icon.py - SideWinder FFB ikon uretici
Calistir: python icon.py
Cikti:    icon.ico (proje klasorune)
"""
import sys, pathlib, math

try:
    from PIL import Image, ImageDraw
except ImportError:
    print("Pillow yuklu degil. Calistir: pip install Pillow")
    sys.exit(1)

def simge_ciz(boyut, renk):
    S  = boyut
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d  = ImageDraw.Draw(im)
    p  = max(int(S * 0.07), 2)
    kl = max(int(S * 0.09), 1)
    # Dis halka
    d.ellipse([p, p, S-p, S-p], outline=renk, width=kl)
    # Merkez
    hr = S * 0.14
    cx = cy = S // 2
    d.ellipse([cx-hr, cy-hr, cx+hr, cy+hr], fill=renk)
    # 3 spok
    r = S//2 - p - kl//2
    for ag in [90, 210, 330]:
        rad = math.radians(ag)
        ex  = cx + r * math.cos(rad)
        ey  = cy - r * math.sin(rad)
        d.line([cx, cy, ex, ey], fill=renk, width=max(kl-1,1))
    return im

def uret(hedef: pathlib.Path):
    renk   = (60, 180, 255)   # Mavi - varsayilan
    boyutlar = [16, 24, 32, 48, 64, 128, 256]
    kareler  = [simge_ciz(b, renk) for b in boyutlar]
    kareler[0].save(
        hedef,
        format="ICO",
        sizes=[(b, b) for b in boyutlar],
        append_images=kareler[1:],
    )
    print(f"[OK]  icon.ico olusturuldu: {hedef}")

if __name__ == "__main__":
    hedef = pathlib.Path(__file__).parent / "icon.ico"
    uret(hedef)

"""
make_spec.py  -  SideWinderFFB PyInstaller Spec Uretici
=======================================================
build_exe.bat tarafindan cagrilir.

V13 DUZELTME:
  Hata: "Failed to load dynlib/dll ...vgameXXX/ViGEmClient.dll"
  Neden: vgamepad paket dizininde .dll dosyalari var, bunlar
         hiddenimports ile degil, sadece binaries ile gomulur.
  Cozum: vgamepad paket dizinindeki tum .dll'leri binaries'e ekle.

Kullanim:
    py -3.12 make_spec.py <proje_klasoru>
"""

import sys
import pathlib
import textwrap


def bul_sdl2(proje):
    local = proje / "SDL2.dll"
    if local.exists():
        return local
    candidates = list(pathlib.Path(sys.prefix).rglob("SDL2.dll"))
    if candidates:
        return candidates[0]
    try:
        import pysdl2_dll
        base = pathlib.Path(pysdl2_dll.__file__).parent
        r = list(base.rglob("SDL2.dll"))
        if r:
            return r[0]
    except ImportError:
        pass
    raise FileNotFoundError("SDL2.dll bulunamadi! Kur-Baslat.bat calistirin.")


def customtkinter_datas():
    try:
        import customtkinter
        base = pathlib.Path(customtkinter.__file__).parent
        return [(str(base), "customtkinter")]
    except ImportError:
        return []


def main():
    if len(sys.argv) < 2:
        proje = pathlib.Path(__file__).parent.resolve()
    else:
        proje = pathlib.Path(sys.argv[1]).resolve()

    print(f"[make_spec] Proje: {proje}")

    sdl2 = bul_sdl2(proje)
    print(f"[make_spec] SDL2.dll: {sdl2}")

    try:
        import pysdl2_dll
        pysdl2_dll_dir = pathlib.Path(pysdl2_dll.__file__).parent
    except ImportError:
        pysdl2_dll_dir = sdl2.parent

    ctk_datas = customtkinter_datas()
    ctk_src   = ctk_datas[0][0] if ctk_datas else ""

    # --- vgamepad DLL'lerini bul ve listele ---
    # Hata mesaji: "Failed to load dynlib/dll ...ViGEmClient.dll"
    # hiddenimports YETMEZ -- .dll dosyalari binaries listesine girmeli
    vgp_dll_lines = []
    try:
        import vgamepad as _vg
        vgp_dir = pathlib.Path(_vg.__file__).parent
        for dll in sorted(vgp_dir.rglob("*.dll")):
            vgp_dll_lines.append(f'        (r"{dll}", "."),')
            print(f"[make_spec] vgamepad DLL bulundu: {dll.name}")
        if not vgp_dll_lines:
            print("[make_spec] UYARI: vgamepad icinde .dll yok!")
    except ImportError:
        print("[make_spec] vgamepad yuklu degil, DLL atlandi.")

    vgp_block = "\n".join(vgp_dll_lines)

    # --- Runtime hook ---
    hook_path = proje / "_rt_hook_sdl2.py"
    hook_path.write_text(
        "import os, sys, pathlib\n"
        "if getattr(sys,'frozen',False) and hasattr(sys,'_MEIPASS'):\n"
        "    mp = sys._MEIPASS\n"
        "    os.environ['PYSDL2_DLL_PATH'] = mp\n"
        "    v = pathlib.Path(mp)/'ViGEmClient.dll'\n"
        "    if v.exists(): os.environ['VIGEM_CLIENT_DLL'] = str(v)\n",
        encoding="utf-8"
    )
    print(f"[make_spec] Hook yazildi: {hook_path}")

    ikon = proje / "icon.ico"
    ikon_str = f'r"{ikon}"' if ikon.exists() else "None"

    ctk_data_line = (f'        (r"{ctk_src}", "customtkinter"),'
                     if ctk_src else "        # customtkinter bulunamadi")

    spec = f"""# SideWinderFFB.spec (otomatik uretildi - make_spec.py)
block_cipher = None
import sys

a = Analysis(
    [r"{proje / 'gui_app.py'}"],
    pathex=[r"{proje}"],
    binaries=[
        (r"{sdl2}", "."),
{vgp_block}
    ],
    datas=[
        (r"{proje / 'sidewinder_ffb.py'}", "."),
{ctk_data_line}
        (r"{pysdl2_dll_dir}", "pysdl2_dll"),
    ],
    hiddenimports=[
        "customtkinter",
        "customtkinter.windows",
        "customtkinter.windows.widgets",
        "customtkinter.windows.widgets.theme",
        "pystray._win32",
        "pystray._base",
        "PIL._tkinter_finder",
        "PIL.ImageDraw",
        "PIL.ImageFont",
        "PIL.IcoImagePlugin",
        "PIL.BmpImagePlugin",
        "PIL.PngImagePlugin",
        "sdl2",
        "sdl2.haptic",
        "sdl2.joystick",
        "sdl2.ext",
        "sdl2.events",
        "vgamepad",
        "vgamepad.win.vigem_target",
        "vgamepad.win.vigem_client",
        "vgamepad.win.vigem_commons",
        "vgamepad.win.vigem_errors",
        "ctypes",
        "ctypes.wintypes",
        "winreg",
        "logging.handlers",
    ],
    hookspath=[],
    runtime_hooks=[r"{hook_path}"],
    excludes=[
        "matplotlib","numpy","scipy","pandas",
        "PyQt5","PyQt6","wx","tkinter.test","test","unittest","doctest",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="SideWinderFFB",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=["SDL2.dll", "ViGEmClient.dll"],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon={ikon_str},
)
"""

    spec_path = proje / "SideWinderFFB.spec"
    spec_path.write_text(spec, encoding="utf-8")
    print(f"[make_spec] Spec yazildi: {spec_path}")
    print("[make_spec] Hazir.")


if __name__ == "__main__":
    main()

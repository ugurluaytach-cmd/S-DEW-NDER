# Changelog

## v4.0 (2025-03)
- Hybrid Gamepad Mode (ViGEmBus / vgamepad)
- Steering calibration: centre, left/right limit teaching
- Live output monitor: 5 progress bars showing what the game receives
- Dual analog crosshair with deadzone visualisation
- Button flash fixed: edge detection, no race condition
- PyInstaller .exe: SDL2.dll + ViGEmClient.dll correctly bundled

## v3.0
- CustomTkinter dark-mode UI
- Button mapping tab (12 controls, 17 functions)
- Steering config tab (rotation, linearity, LPF, Hz)
- Calibration tab with live steering bar and pedal bars
- System tray with animated icon

## v2.0
- UDP telemetry receiver (Forza / F1 auto-detect)
- SDL2 FFB engine: spring, damper, sine effects
- Automatic SDL2.dll discovery and download
- Windows startup registry integration

## v1.0
- Initial release: CLI-only FFB wrapper
